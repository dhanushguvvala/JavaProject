@echo off
cd /d "%~dp0"
if exist out rmdir /s /q out
mkdir out
javac -d out -encoding UTF-8 Main.java model\*.java service\*.java util\*.java gui\*.java
if errorlevel 1 (
    pause
    exit /b 1
)
java -cp out Main
