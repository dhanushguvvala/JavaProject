package model;

import java.util.Set;

public final class Categories {

    public static final String[] INCOME = {
            "Salary", "Freelance", "Business", "Investment", "Gift", "Other"
    };

    public static final String[] EXPENSE = {
            "Food", "Rent", "Transport", "Utilities", "Health",
            "Education", "Shopping", "Entertainment", "Other"
    };

    public static final Set<String> DISCRETIONARY = Set.of("Shopping", "Entertainment");

    private Categories() {
    }

    public static String[] forType(String type) {
        return "Income".equalsIgnoreCase(type) ? INCOME : EXPENSE;
    }
}
