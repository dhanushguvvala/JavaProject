package model;

import java.time.LocalDate;
import java.time.YearMonth;

public class Transaction {

    private final int id;
    private double amount;
    private String description;
    private String type;
    private String category;
    private LocalDate date;

    public Transaction(int id, double amount, String description, String type, String category, LocalDate date) {
        this.id = id;
        this.amount = amount;
        this.description = description == null ? "" : description;
        this.type = type;
        this.category = (category == null || category.trim().isEmpty()) ? "Other" : category;
        this.date = date == null ? LocalDate.now() : date;
    }

    public int getId() {
        return id;
    }

    public double getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }

    public String getType() {
        return type;
    }

    public String getCategory() {
        return category;
    }

    public LocalDate getDate() {
        return date;
    }

    public YearMonth getMonth() {
        return YearMonth.from(date);
    }

    public boolean isIncome() {
        return "Income".equalsIgnoreCase(type);
    }

    public boolean isExpense() {
        return "Expense".equalsIgnoreCase(type);
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setCategory(String category) {
        if (category != null && !category.trim().isEmpty()) {
            this.category = category;
        }
    }

    public void setDate(LocalDate date) {
        if (date != null) {
            this.date = date;
        }
    }

    public String toCsvLine() {
        return id + "|" + amount + "|" + description.replace("|", "/") + "|" + type + "|" + category + "|" + date;
    }

    public static Transaction fromCsvLine(String line) {
        String[] p = line.split("\\|", -1);
        int id = Integer.parseInt(p[0].trim());
        double amount = Double.parseDouble(p[1].trim());
        String type = p[3].trim();
        String category = p.length > 4 ? p[4].trim() : "Other";
        LocalDate date = p.length > 5 && !p[5].trim().isEmpty() ? LocalDate.parse(p[5].trim()) : LocalDate.now();
        return new Transaction(id, amount, p[2], type, category, date);
    }
}
