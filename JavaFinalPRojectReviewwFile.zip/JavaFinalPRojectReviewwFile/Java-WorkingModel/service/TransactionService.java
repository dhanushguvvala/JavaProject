package service;

import model.Transaction;
import util.FileManager;

import java.io.IOException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

public class TransactionService {

    private final String username;
    private final List<Transaction> transactions;

    public TransactionService(String username) {
        this.username = username;
        List<Transaction> loaded;
        try {
            loaded = FileManager.loadTransactions(username);
        } catch (IOException e) {
            loaded = new ArrayList<>();
        }
        this.transactions = loaded;
    }

    private int nextId() {
        int max = 0;
        for (Transaction t : transactions) {
            max = Math.max(max, t.getId());
        }
        return max + 1;
    }

    private void persist() {
        try {
            FileManager.saveTransactions(username, transactions);
        } catch (IOException ignored) {
        }
    }

    public Transaction add(String type, double amount, String description, String category, LocalDate date) {
        Transaction t = new Transaction(nextId(), amount, description, type, category, date);
        transactions.add(t);
        persist();
        return t;
    }

    public boolean update(int id, String type, double amount, String description, String category, LocalDate date) {
        Transaction t = find(id);
        if (t == null) {
            return false;
        }
        t.setType(type);
        t.setAmount(amount);
        t.setDescription(description);
        t.setCategory(category);
        t.setDate(date);
        persist();
        return true;
    }

    public boolean delete(int id) {
        boolean removed = transactions.removeIf(t -> t.getId() == id);
        if (removed) {
            persist();
        }
        return removed;
    }

    public Transaction find(int id) {
        for (Transaction t : transactions) {
            if (t.getId() == id) {
                return t;
            }
        }
        return null;
    }

    public List<Transaction> getTransactions() {
        return Collections.unmodifiableList(transactions);
    }

    public List<Transaction> getTransactions(YearMonth month) {
        return transactions.stream()
                .filter(t -> t.getMonth().equals(month))
                .sorted(Comparator.comparing(Transaction::getDate).thenComparing(Transaction::getId).reversed())
                .collect(Collectors.toList());
    }

    public double getIncome(YearMonth month) {
        return sum(month, true);
    }

    public double getExpense(YearMonth month) {
        return sum(month, false);
    }

    private double sum(YearMonth month, boolean income) {
        double total = 0;
        for (Transaction t : transactions) {
            if (t.getMonth().equals(month) && (income ? t.isIncome() : t.isExpense())) {
                total += t.getAmount();
            }
        }
        return total;
    }

    public Map<String, Double> getExpenseByCategory(YearMonth month) {
        Map<String, Double> totals = new HashMap<>();
        for (Transaction t : transactions) {
            if (t.isExpense() && t.getMonth().equals(month)) {
                totals.merge(t.getCategory(), t.getAmount(), Double::sum);
            }
        }
        return sortDesc(totals);
    }

    public double[] getDailyExpense(YearMonth month) {
        double[] days = new double[month.lengthOfMonth()];
        for (Transaction t : transactions) {
            if (t.isExpense() && t.getMonth().equals(month)) {
                days[t.getDate().getDayOfMonth() - 1] += t.getAmount();
            }
        }
        return days;
    }

    public List<Transaction> getTopExpenses(YearMonth month, int limit) {
        return transactions.stream()
                .filter(t -> t.isExpense() && t.getMonth().equals(month))
                .sorted(Comparator.comparingDouble(Transaction::getAmount).reversed())
                .limit(limit)
                .collect(Collectors.toList());
    }

    public int countExpenses(YearMonth month) {
        int count = 0;
        for (Transaction t : transactions) {
            if (t.isExpense() && t.getMonth().equals(month)) {
                count++;
            }
        }
        return count;
    }

    public boolean hasData(YearMonth month) {
        for (Transaction t : transactions) {
            if (t.getMonth().equals(month)) {
                return true;
            }
        }
        return false;
    }

    public YearMonth getLatestMonth() {
        return transactions.stream().map(Transaction::getMonth).max(Comparator.naturalOrder()).orElse(YearMonth.now());
    }

    public List<YearMonth> getMonthRange() {
        YearMonth now = YearMonth.now();
        YearMonth first = transactions.stream().map(Transaction::getMonth).min(Comparator.naturalOrder()).orElse(now);
        YearMonth last = transactions.stream().map(Transaction::getMonth).max(Comparator.naturalOrder()).orElse(now);
        if (now.isAfter(last)) {
            last = now;
        }
        List<YearMonth> months = new ArrayList<>();
        for (YearMonth m = last; !m.isBefore(first); m = m.minusMonths(1)) {
            months.add(m);
        }
        return months;
    }

    public List<YearMonth> getMonthsWithData(YearMonth upTo, int max) {
        return transactions.stream()
                .map(Transaction::getMonth)
                .filter(m -> !m.isAfter(upTo))
                .distinct()
                .sorted(Comparator.reverseOrder())
                .limit(max)
                .collect(Collectors.toList());
    }

    public static Map<String, Double> sortDesc(Map<String, Double> map) {
        return map.entrySet().stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> a, LinkedHashMap::new));
    }
}
