package service;

import java.io.IOException;

import model.User;
import util.FileManager;
import util.PasswordUtil;
import util.Session;

public class LoginService {

    public String register(String username, String password) {

        try {

            if (FileManager.userExists(username)) {
                return "That username is already taken.";
            }

            User user = new User(username, PasswordUtil.hash(password));

            FileManager.saveUser(user);

            return null;

        } catch (IOException e) {

            return "Could not save account: " + e.getMessage();

        }
    }

    public boolean login(String username, String password) {

        try {

            User user = FileManager.findUser(username);

            if (user == null) {
                return false;
            }

            boolean success = user.getPassword().equals(PasswordUtil.hash(password));

            if (success) {
                Session.setCurrentUser(username);
            }

            return success;

        } catch (IOException e) {

            return false;

        }
    }
}
