package service;

import model.Categories;
import model.Transaction;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class FinancialAnalysisService {

    public enum Kind { POSITIVE, WARNING, TIP, FORECAST }

    public record Insight(Kind kind, String title, String detail) {
    }

    public record Factor(String name, int score, int max, String note) {
    }

    public record Report(YearMonth month, boolean hasData, int score, String grade, String summary,
                         double income, double expense, double savings, double savingsRate,
                         List<Factor> factors, List<Insight> insights) {

        public List<Insight> of(Kind kind) {
            return insights.stream().filter(i -> i.kind() == kind).toList();
        }
    }

    private static final DateTimeFormatter MONTH = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH);
    private static final DateTimeFormatter SHORT_MONTH = DateTimeFormatter.ofPattern("MMMM", Locale.ENGLISH);
    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH);

    private static final String[][] KEYWORDS = {
            {"rent", "Rent"}, {"grocer", "Food"}, {"dinner", "Food"}, {"lunch", "Food"}, {"breakfast", "Food"},
            {"restaurant", "Food"}, {"swiggy", "Food"}, {"zomato", "Food"}, {"fuel", "Transport"},
            {"petrol", "Transport"}, {"diesel", "Transport"}, {"uber", "Transport"}, {"ola", "Transport"},
            {"metro", "Transport"}, {"bus", "Transport"}, {"train", "Transport"}, {"electricity", "Utilities"},
            {"internet", "Utilities"}, {"wifi", "Utilities"}, {"water bill", "Utilities"}, {"recharge", "Utilities"},
            {"school", "Education"}, {"college", "Education"}, {"tuition", "Education"}, {"course", "Education"},
            {"medic", "Health"}, {"doctor", "Health"}, {"hospital", "Health"}, {"pharma", "Health"},
            {"insurance", "Health"}, {"movie", "Entertainment"}, {"netflix", "Entertainment"},
            {"spotify", "Entertainment"}, {"clothes", "Shopping"}, {"amazon", "Shopping"}, {"flipkart", "Shopping"}
    };

    private final TransactionService transactions;
    private final BudgetService budgets;

    public FinancialAnalysisService(TransactionService transactions, BudgetService budgets) {
        this.transactions = transactions;
        this.budgets = budgets;
    }

    public Report analyze(YearMonth month) {
        double income = transactions.getIncome(month);
        double expense = transactions.getExpense(month);
        double savings = income - expense;
        double rate = income > 0 ? savings / income * 100 : 0;
        String monthName = MONTH.format(month);

        if (!transactions.hasData(month)) {
            return new Report(month, false, 0, "No data",
                    "No transactions recorded for " + monthName + ". Add income and expenses to get your analysis.",
                    0, 0, 0, 0, List.of(), List.of());
        }

        YearMonth prev = month.minusMonths(1);
        boolean hasPrev = transactions.hasData(prev);
        double prevExpense = transactions.getExpense(prev);
        Map<String, Double> cats = transactions.getExpenseByCategory(month);
        Map<String, Double> prevCats = transactions.getExpenseByCategory(prev);

        boolean inProgress = month.equals(YearMonth.now()) && LocalDate.now().getDayOfMonth() < month.lengthOfMonth();
        double pace = inProgress ? expense / LocalDate.now().getDayOfMonth() * month.lengthOfMonth() : expense;

        List<Factor> factors = new ArrayList<>();
        factors.add(savingsFactor(income, rate));
        factors.add(budgetFactor(cats));
        factors.add(balanceFactor(cats, expense));
        factors.add(discretionaryFactor(cats, expense));
        factors.add(trendFactor(hasPrev, prevExpense, pace, prev, inProgress));

        int score = factors.stream().mapToInt(Factor::score).sum();
        String grade = grade(score);

        List<Insight> insights = new ArrayList<>();
        savingsInsights(insights, income, expense, savings, rate);
        categoryInsights(insights, cats, expense);
        trendInsights(insights, hasPrev, prev, cats, prevCats, pace, prevExpense, inProgress);
        budgetInsights(insights, cats);
        discretionaryInsights(insights, cats, expense);
        largestExpenseInsight(insights, month);
        categorisationInsights(insights, month);
        forecastInsights(insights, month, expense, savings);

        String summary = summary(monthName, grade, income, savings, rate);
        return new Report(month, true, score, grade, summary, income, expense, savings, rate, factors, insights);
    }

    private Factor savingsFactor(double income, double rate) {
        if (income <= 0) {
            return new Factor("Savings rate", 0, 35, "No income recorded this month");
        }
        int pts = (int) Math.round(clamp(rate / 30.0) * 35);
        return new Factor("Savings rate", pts, 35, String.format("%.1f%% of income saved (target 30%%)", rate));
    }

    private Factor budgetFactor(Map<String, Double> cats) {
        if (!budgets.hasBudgets()) {
            return new Factor("Budget discipline", 10, 20, "No budgets set yet");
        }
        double totalLimit = 0;
        double overspend = 0;
        int over = 0;
        for (Map.Entry<String, Double> e : budgets.getLimits().entrySet()) {
            double spent = cats.getOrDefault(e.getKey(), 0.0);
            totalLimit += e.getValue();
            if (spent > e.getValue()) {
                overspend += spent - e.getValue();
                over++;
            }
        }
        int pts = (int) Math.round(clamp(1 - overspend / Math.max(1, totalLimit) * 2) * 20);
        String note = over == 0 ? "All budgets within limit" : over + (over == 1 ? " budget" : " budgets") + " exceeded";
        return new Factor("Budget discipline", pts, 20, note);
    }

    private Factor balanceFactor(Map<String, Double> cats, double expense) {
        if (expense <= 0) {
            return new Factor("Spending balance", 15, 15, "No expenses recorded");
        }
        Map.Entry<String, Double> top = cats.entrySet().iterator().next();
        double share = top.getValue() / expense * 100;
        int pts = (int) Math.round(clamp((75 - share) / 40.0) * 15);
        return new Factor("Spending balance", pts, 15, String.format("%s takes %.0f%% of spending", top.getKey(), share));
    }

    private Factor discretionaryFactor(Map<String, Double> cats, double expense) {
        double disc = discretionary(cats);
        double share = expense > 0 ? disc / expense * 100 : 0;
        int pts = (int) Math.round(clamp((40 - share) / 30.0) * 15);
        return new Factor("Lifestyle spending", pts, 15, String.format("%.0f%% on shopping and entertainment", share));
    }

    private Factor trendFactor(boolean hasPrev, double prevExpense, double expense, YearMonth prev, boolean projected) {
        if (!hasPrev || prevExpense <= 0) {
            return new Factor("Spending trend", 10, 15, "No previous month to compare");
        }
        double change = (expense - prevExpense) / prevExpense * 100;
        int pts = (int) Math.round(clamp((30 - change) / 30.0) * 15);
        String dir = change >= 0 ? "up" : "down";
        return new Factor("Spending trend", pts, 15,
                String.format("%s %s %.0f%% vs %s", projected ? "Projected spending" : "Expenses", dir, Math.abs(change), SHORT_MONTH.format(prev)));
    }

    private void savingsInsights(List<Insight> out, double income, double expense, double savings, double rate) {
        if (income <= 0) {
            out.add(new Insight(Kind.WARNING, "No income recorded",
                    "You spent " + money(expense) + " but logged no income this month. Add income entries so your score reflects reality."));
            return;
        }
        if (savings < 0) {
            out.add(new Insight(Kind.WARNING, "Spending exceeded income",
                    "You spent " + money(-savings) + " more than you earned. Cover the gap by trimming the categories flagged below."));
        } else if (rate >= 20) {
            out.add(new Insight(Kind.POSITIVE, String.format("Healthy savings rate of %.1f%%", rate),
                    "You kept " + money(savings) + " of " + money(income) + ". That beats the 20% savings guideline of the 50/30/20 rule."));
        } else {
            double gap = income * 0.2 - savings;
            out.add(new Insight(Kind.WARNING, String.format("Savings rate is %.1f%%", rate),
                    "Saving " + money(gap) + " more this month would bring you to the 20% guideline."));
        }
    }

    private void categoryInsights(List<Insight> out, Map<String, Double> cats, double expense) {
        if (cats.isEmpty()) {
            return;
        }
        Map.Entry<String, Double> top = cats.entrySet().iterator().next();
        double share = top.getValue() / expense * 100;
        if (share > 45) {
            out.add(new Insight(Kind.WARNING, String.format("%s dominates spending (%.0f%%)", top.getKey(), share),
                    money(top.getValue()) + " went to " + top.getKey() + ". Check whether every entry here really belongs to this category."));
        } else {
            out.add(new Insight(Kind.POSITIVE, "Spending is well spread",
                    String.format("Your largest category, %s, is %.0f%% of spending, so no single area is overwhelming your budget.", top.getKey(), share)));
        }
    }

    private void trendInsights(List<Insight> out, boolean hasPrev, YearMonth prev, Map<String, Double> cats,
                               Map<String, Double> prevCats, double expense, double prevExpense, boolean projected) {
        if (!hasPrev || prevExpense <= 0) {
            return;
        }
        String prevName = SHORT_MONTH.format(prev);
        double change = (expense - prevExpense) / prevExpense * 100;
        String label = projected ? "Projected spending" : "Spending";
        String verb = projected ? "You're on track to spend " : "You spent ";
        if (change <= -5) {
            out.add(new Insight(Kind.POSITIVE, String.format("%s down %.0f%% vs %s", label, -change, prevName),
                    verb + money(prevExpense - expense) + " less than last month."));
        } else if (change >= 10) {
            out.add(new Insight(Kind.WARNING, String.format("%s up %.0f%% vs %s", label, change, prevName),
                    verb + money(expense - prevExpense) + " more than last month."));
        }

        int ups = 0;
        for (Map.Entry<String, Double> e : cats.entrySet()) {
            double before = prevCats.getOrDefault(e.getKey(), 0.0);
            double diff = e.getValue() - before;
            if (before > 0 && diff >= 500 && diff / before >= 0.25 && ups < 2) {
                out.add(new Insight(Kind.WARNING, String.format("%s up %.0f%% vs %s", e.getKey(), diff / before * 100, prevName),
                        e.getKey() + " rose by " + money(diff) + " to " + money(e.getValue()) + "."));
                ups++;
            }
        }
    }

    private void budgetInsights(List<Insight> out, Map<String, Double> cats) {
        if (!budgets.hasBudgets()) {
            out.add(new Insight(Kind.TIP, "Set monthly budgets",
                    "Add limits on the Budgets page for your top categories. You'll get alerts when you overspend and can earn up to 10 more score points."));
            return;
        }
        for (Map.Entry<String, Double> e : budgets.getLimits().entrySet()) {
            double spent = cats.getOrDefault(e.getKey(), 0.0);
            switch (BudgetService.status(spent, e.getValue())) {
                case OVER -> out.add(new Insight(Kind.WARNING, e.getKey() + " budget exceeded",
                        "Spent " + money(spent) + " against a " + money(e.getValue()) + " limit, over by " + money(spent - e.getValue()) + "."));
                case NEAR_LIMIT -> out.add(new Insight(Kind.TIP, e.getKey() + " is close to its limit",
                        String.format("%.0f%% of the %s budget is used. Slow down here for the rest of the month.", spent / e.getValue() * 100, money(e.getValue()))));
                default -> {
                }
            }
        }
    }

    private void discretionaryInsights(List<Insight> out, Map<String, Double> cats, double expense) {
        double disc = discretionary(cats);
        if (expense <= 0) {
            return;
        }
        double share = disc / expense * 100;
        if (share >= 15) {
            out.add(new Insight(Kind.TIP, "Trim lifestyle spending",
                    String.format("Shopping and entertainment are %.0f%% of spending. Cutting them by a quarter would save about %s a month.", share, money(disc * 0.25))));
        } else if (disc > 0) {
            out.add(new Insight(Kind.POSITIVE, "Lifestyle spending under control",
                    String.format("Only %.0f%% of spending went to shopping and entertainment.", share)));
        }
    }

    private void largestExpenseInsight(List<Insight> out, YearMonth month) {
        List<Transaction> top = transactions.getTopExpenses(month, 1);
        if (!top.isEmpty()) {
            Transaction t = top.get(0);
            out.add(new Insight(Kind.FORECAST, "Largest single expense",
                    t.getDescription() + " (" + t.getCategory() + ") for " + money(t.getAmount()) + " on " + DAY.format(t.getDate()) + "."));
        }
    }

    private void categorisationInsights(List<Insight> out, YearMonth month) {
        int found = 0;
        for (Transaction t : transactions.getTransactions(month)) {
            String suggested = suggestCategory(t.getDescription());
            if (suggested == null) {
                continue;
            }
            if (t.isIncome()) {
                out.add(new Insight(Kind.TIP, "Check \"" + t.getDescription() + "\"",
                        "It's recorded as income, but it looks like a " + suggested + " expense. Fixing it will correct your totals."));
                found++;
            } else if (!suggested.equals(t.getCategory())) {
                out.add(new Insight(Kind.TIP, "Recategorise \"" + t.getDescription() + "\"",
                        "It's filed under " + t.getCategory() + " but looks like " + suggested + ". Accurate categories make this analysis sharper."));
                found++;
            }
            if (found == 3) {
                break;
            }
        }
    }

    private void forecastInsights(List<Insight> out, YearMonth month, double expense, double savings) {
        YearMonth now = YearMonth.now();
        if (month.equals(now)) {
            int day = LocalDate.now().getDayOfMonth();
            int days = month.lengthOfMonth();
            if (day < days && expense > 0) {
                double projected = expense / day * days;
                out.add(new Insight(Kind.FORECAST, "Month-end projection",
                        "At your current pace you'll spend about " + money(projected) + " by the end of " + SHORT_MONTH.format(month) + "."));
            }
        }

        List<YearMonth> recent = transactions.getMonthsWithData(month, 3);
        double total = 0;
        for (YearMonth m : recent) {
            total += transactions.getExpense(m);
        }
        if (!recent.isEmpty() && total > 0) {
            double avg = total / recent.size();
            out.add(new Insight(Kind.FORECAST, "Expected spending next month",
                    "About " + money(avg) + ", based on your average over the last " + recent.size() + (recent.size() == 1 ? " month." : " months.")));
        }

        if (savings > 0 && expense > 0) {
            double target = expense * 6;
            double months = Math.ceil(target / savings);
            out.add(new Insight(Kind.FORECAST, "Emergency fund timeline",
                    String.format("Saving %s a month builds a 6-month emergency fund (%s) in about %.0f months.", money(savings), money(target), months)));
        }
    }

    private String summary(String monthName, String grade, double income, double savings, double rate) {
        String rating = " Overall rating: " + grade + ".";
        if (income <= 0) {
            return "In " + monthName + " you recorded expenses but no income." + rating;
        }
        if (savings < 0) {
            return "In " + monthName + " you overspent by " + money(-savings) + "." + rating;
        }
        return String.format("In %s you saved %s (%.1f%% of income).", monthName, money(savings), rate) + rating;
    }

    public static String grade(int score) {
        if (score >= 85) return "Excellent";
        if (score >= 70) return "Good";
        if (score >= 55) return "Fair";
        if (score >= 40) return "Needs attention";
        return "At risk";
    }

    public static String suggestCategory(String description) {
        String d = " " + description.toLowerCase(Locale.ENGLISH) + " ";
        for (String[] k : KEYWORDS) {
            if (k[0].length() <= 3 ? d.contains(" " + k[0] + " ") : d.contains(k[0])) {
                return k[1];
            }
        }
        return null;
    }

    private static double discretionary(Map<String, Double> cats) {
        double total = 0;
        for (String c : Categories.DISCRETIONARY) {
            total += cats.getOrDefault(c, 0.0);
        }
        return total;
    }

    private static double clamp(double v) {
        return Math.max(0, Math.min(1, v));
    }

    public static String money(double v) {
        return util.Money.format(v);
    }
}
