package service;

import util.FileManager;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class BudgetService {

    public enum Status { NONE, ON_TRACK, NEAR_LIMIT, OVER }

    private final String username;
    private final Map<String, Double> limits;

    public BudgetService(String username) {
        this.username = username;
        Map<String, Double> loaded;
        try {
            loaded = FileManager.loadBudgets(username);
        } catch (IOException e) {
            loaded = new LinkedHashMap<>();
        }
        this.limits = loaded;
    }

    public Map<String, Double> getLimits() {
        return Collections.unmodifiableMap(limits);
    }

    public double getLimit(String category) {
        return limits.getOrDefault(category, 0.0);
    }

    public boolean hasBudgets() {
        return !limits.isEmpty();
    }

    public void setLimits(Map<String, Double> newLimits) {
        limits.clear();
        newLimits.forEach((k, v) -> {
            if (v != null && v > 0) {
                limits.put(k, v);
            }
        });
        try {
            FileManager.saveBudgets(username, limits);
        } catch (IOException ignored) {
        }
    }

    public static Status status(double spent, double limit) {
        if (limit <= 0) {
            return Status.NONE;
        }
        if (spent > limit) {
            return Status.OVER;
        }
        if (spent >= limit * 0.8) {
            return Status.NEAR_LIMIT;
        }
        return Status.ON_TRACK;
    }
}
