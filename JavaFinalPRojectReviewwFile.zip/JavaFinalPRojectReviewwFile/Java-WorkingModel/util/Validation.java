package util;

public class Validation {

    public static boolean isValidAmount(double amount) {
        return amount > 0;
    }

    public static boolean isValidDescription(String description) {
        return description != null && !description.trim().isEmpty();
    }

    public static boolean isValidUsername(String username) {

        if (username == null)
            return false;

        username = username.trim();

        return username.length() >= 4;
    }

    public static boolean isValidPassword(String password) {

        if (password == null)
            return false;

        return password.length() >= 6;
    }

}