package util;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public final class Money {

    private static final String RUPEE = "\u20B9";

    private Money() {
    }

    public static String format(double value) {
        boolean negative = value < 0;
        double v = Math.abs(value);
        boolean whole = Math.abs(v - Math.rint(v)) < 0.005;
        long rupees = whole ? Math.round(v) : (long) Math.floor(v);
        String body = indianGrouping(rupees);
        if (!whole) {
            long paise = Math.round((v - rupees) * 100);
            if (paise == 100) {
                body = indianGrouping(rupees + 1);
            } else {
                body += "." + (paise < 10 ? "0" + paise : String.valueOf(paise));
            }
        }
        return (negative ? "-" : "") + RUPEE + body;
    }

    public static String signed(double value, boolean income) {
        return (income ? "+" : "\u2212") + format(Math.abs(value));
    }

    public static String compact(double value) {
        double v = Math.abs(value);
        String s;
        if (v >= 10000000) {
            s = trim(v / 10000000) + "Cr";
        } else if (v >= 100000) {
            s = trim(v / 100000) + "L";
        } else if (v >= 1000) {
            s = trim(v / 1000) + "k";
        } else {
            s = String.valueOf(Math.round(v));
        }
        return (value < 0 ? "-" : "") + RUPEE + s;
    }

    private static String trim(double v) {
        return new DecimalFormat("0.#", DecimalFormatSymbols.getInstance(Locale.ENGLISH)).format(v);
    }

    private static String indianGrouping(long n) {
        String s = Long.toString(n);
        if (s.length() <= 3) {
            return s;
        }
        String last3 = s.substring(s.length() - 3);
        String rest = s.substring(0, s.length() - 3);
        StringBuilder sb = new StringBuilder();
        int i = rest.length();
        while (i > 2) {
            sb.insert(0, "," + rest.substring(i - 2, i));
            i -= 2;
        }
        sb.insert(0, rest.substring(0, i));
        return sb + "," + last3;
    }
}
