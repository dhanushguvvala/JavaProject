package util;

public class Session {

    private static String currentUser;

    private Session() {
    }

    public static void setCurrentUser(String username) {
        currentUser = username;
    }

    public static String getCurrentUser() {
        return currentUser;
    }

    public static void clear() {
        currentUser = null;
    }

}
