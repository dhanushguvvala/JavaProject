package util;

import model.Transaction;
import model.User;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class FileManager {

    private static final String DATA_DIR = "data";
    private static final String USERS_FILE = DATA_DIR + "/users.txt";

    private FileManager() {
    }

    private static void ensureDataDir() {
        File folder = new File(DATA_DIR);
        if (!folder.exists()) {
            folder.mkdirs();
        }
    }

    private static String safe(String username) {
        return username.replaceAll("[^a-zA-Z0-9_.-]", "_");
    }

    private static BufferedReader reader(File file) throws IOException {
        return new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
    }

    private static BufferedWriter writer(String path, boolean append) throws IOException {
        return new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path, append), StandardCharsets.UTF_8));
    }

    public static boolean userExists(String username) throws IOException {
        return findUser(username) != null;
    }

    public static void saveUser(User user) throws IOException {
        ensureDataDir();
        try (BufferedWriter bw = writer(USERS_FILE, true)) {
            bw.write(user.getUsername() + "," + user.getPassword());
            bw.newLine();
        }
    }

    public static User findUser(String username) throws IOException {
        File file = new File(USERS_FILE);
        if (!file.exists()) {
            return null;
        }
        try (BufferedReader br = reader(file)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.trim().split(",", 2);
                if (parts.length == 2 && parts[0].equals(username)) {
                    return new User(parts[0], parts[1]);
                }
            }
        }
        return null;
    }

    public static List<Transaction> loadTransactions(String username) throws IOException {
        List<Transaction> transactions = new ArrayList<>();
        File file = new File(DATA_DIR + "/transactions_" + safe(username) + ".txt");
        if (!file.exists()) {
            return transactions;
        }
        try (BufferedReader br = reader(file)) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                try {
                    transactions.add(Transaction.fromCsvLine(line.trim()));
                } catch (RuntimeException ignored) {
                }
            }
        }
        return transactions;
    }

    public static void saveTransactions(String username, List<Transaction> transactions) throws IOException {
        ensureDataDir();
        try (BufferedWriter bw = writer(DATA_DIR + "/transactions_" + safe(username) + ".txt", false)) {
            for (Transaction t : transactions) {
                bw.write(t.toCsvLine());
                bw.newLine();
            }
        }
    }

    public static Map<String, Double> loadBudgets(String username) throws IOException {
        Map<String, Double> budgets = new LinkedHashMap<>();
        File file = new File(DATA_DIR + "/budgets_" + safe(username) + ".txt");
        if (!file.exists()) {
            return budgets;
        }
        try (BufferedReader br = reader(file)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.trim().split("\\|");
                if (p.length == 2) {
                    try {
                        budgets.put(p[0], Double.parseDouble(p[1]));
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }
        return budgets;
    }

    public static void saveBudgets(String username, Map<String, Double> budgets) throws IOException {
        ensureDataDir();
        try (BufferedWriter bw = writer(DATA_DIR + "/budgets_" + safe(username) + ".txt", false)) {
            for (Map.Entry<String, Double> e : budgets.entrySet()) {
                bw.write(e.getKey() + "|" + e.getValue());
                bw.newLine();
            }
        }
    }
}
