# Personal Finance Tracker (Java Swing)

A desktop income and expense tracker with monthly reports, budgets and an
on-device financial score. Built with plain Java Swing, no external libraries.

## How to run

Windows: extract the zip and double-click `run.bat`.

Any OS, from the project root:

```bash
javac -d out -encoding UTF-8 Main.java model/*.java service/*.java util/*.java gui/*.java
java -cp out Main
```

Or open the folder in IntelliJ and run `Main.java`. Always run from the project
root so the app can find the `data/` folder. Requires Java 17 or newer.

## Features

- **Login and register** with SHA-256 hashed passwords and separate data per user.
- **Month selector** in the top bar. Every page follows the selected month.
- **Dashboard**: income, expenses, savings and financial score for the month,
  a 6-month income vs expense chart (click a month to jump to it), spending by
  category donut, recent transactions and budget status.
- **Transactions**: search, filter by type, category and month, sortable
  columns, double-click to edit, right-click menu, delete with confirmation,
  and CSV export of the current view.
- **Monthly report**: total and daily average spend, daily spending chart,
  category breakdown with change from last month, month-over-month comparison
  and the top 5 expenses.
- **AI analysis**: a 0-100 financial score for the selected month with a
  grade (Excellent, Good, Fair, Needs attention, At risk) plus insights grouped
  into what's going well, what needs attention, recommendations and forecasts.
- **Budgets**: a monthly limit per expense category with progress and status,
  and an alert when a new expense pushes a category near or over its limit.
- **Smart category**: typing a description such as "Uber ride" or
  "Electricity bill" auto-selects the matching category.

## How the financial score works

The analysis is rule-based and runs entirely on your machine. No data leaves
the app. The score adds up five factors:

| Factor             | Points | Full points when                                  |
|--------------------|--------|---------------------------------------------------|
| Savings rate       | 35     | you save 30% or more of income                    |
| Budget discipline  | 20     | every budgeted category stays within its limit    |
| Spending balance   | 15     | no single category exceeds about 35% of spending  |
| Lifestyle spending | 15     | shopping and entertainment stay under about 10%   |
| Spending trend     | 15     | spending did not rise versus the previous month   |

If no budgets are set, budget discipline gives 10 of 20. If there is no
previous month, spending trend gives 10 of 15. For the current month the trend
uses projected month-end spending, so a half-finished month is compared fairly.

The insights also flag entries that look miscategorised, such as "House Rent"
filed under Food or "Groceries" recorded as income.

## Project structure

```
Main.java                      entry point
gui/
  LoginFrame.java              login screen
  RegisterFrame.java           registration screen
  AuthComponents.java          shared login/register UI pieces
  Dashboard.java               main window: sidebar, top bar, month selector
  AppContext.java              shared services, selected month, add/edit/delete flows
  Page.java                    base class and row layout for pages
  OverviewPage.java            dashboard page
  TransactionsPage.java        transactions table, filters, CSV export
  MonthlyReportPage.java       monthly report page
  AnalysisPage.java            financial score and insights page
  BudgetsPage.java             budget limits page
  TransactionDialog.java       add and edit transaction dialog
  MessageDialog.java           styled message and confirm dialogs
  Charts.java                  bar chart, donut chart, score gauge
  UI.java                      theme colours and reusable components
  Icons.java                   vector icons drawn with Java2D
  DateSpinnerUtil.java         date picker helper
model/
  User.java
  Transaction.java
  Categories.java              income and expense category lists
service/
  LoginService.java            register and login
  TransactionService.java      transactions, monthly totals and breakdowns
  BudgetService.java           budget limits and status
  FinancialAnalysisService.java  monthly score and insights engine
util/
  FileManager.java             users, transactions and budgets file I/O
  Money.java                   rupee formatting with Indian digit grouping
  PasswordUtil.java            SHA-256 hashing
  Session.java                 logged-in user
  Validation.java              input validation
data/
  users.txt                    accounts
  transactions_<user>.txt      each user's transactions
  budgets_<user>.txt           each user's budget limits (created on save)
```
