package gui;

import service.LoginService;
import util.Validation;

import javax.swing.*;
import java.awt.*;

import static gui.AuthComponents.*;

public class RegisterFrame extends JFrame {

    private final HintTextField usernameField = new HintTextField("Enter username");
    private final HintPasswordField passwordField = new HintPasswordField("Enter password");
    private final HintPasswordField confirmField = new HintPasswordField("Confirm password");

    public RegisterFrame() {

        setTitle("Personal Finance Tracker - Register");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        PrimaryButton registerButton = new PrimaryButton("Create Account", true);
        OutlineButton backButton = new OutlineButton("Back to Login", true);

        FormPanel form = new FormPanel()
                .heading("Create Your Account", "Start managing your finances")
                .field("Username", new IconField(usernameField, FieldIcon.USER), 28)
                .field("Password", new IconField(passwordField, FieldIcon.LOCK), 18)
                .field("Confirm Password", new IconField(confirmField, FieldIcon.LOCK), 18)
                .row(registerButton, 30)
                .row(backButton, 18);

        setContentPane(AuthComponents.layout(form));

        registerButton.addActionListener(e -> register());

        backButton.addActionListener(e -> {
            dispose();
            new LoginFrame();
        });

        getRootPane().setDefaultButton(registerButton);

        setSize(1000, 720);
        setMinimumSize(new Dimension(920, 680));
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void register() {

        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirm = new String(confirmField.getPassword());

        if (username.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            MessageDialog.show(this, "Details Required",
                    "Please fill in username, password and confirm password.", MessageDialog.Type.INFO);
            return;
        }

        if (!Validation.isValidUsername(username)) {
            MessageDialog.show(this, "Invalid Username",
                    "Username must be at least 4 characters.", MessageDialog.Type.WARNING);
            usernameField.requestFocusInWindow();
            return;
        }

        if (!Validation.isValidPassword(password)) {
            MessageDialog.show(this, "Weak Password",
                    "Password must be at least 6 characters.", MessageDialog.Type.WARNING);
            passwordField.requestFocusInWindow();
            return;
        }

        if (!password.equals(confirm)) {
            MessageDialog.show(this, "Password Mismatch",
                    "Passwords do not match.", MessageDialog.Type.WARNING);
            confirmField.setText("");
            confirmField.requestFocusInWindow();
            return;
        }

        LoginService loginService = new LoginService();
        String error = loginService.register(username, password);

        if (error == null) {
            MessageDialog.show(this, "Account Created",
                    "Registration successful! You can now log in.", MessageDialog.Type.SUCCESS);
            dispose();
            new LoginFrame();
        } else {
            MessageDialog.show(this, "Registration Failed", error, MessageDialog.Type.ERROR);
        }
    }
}
