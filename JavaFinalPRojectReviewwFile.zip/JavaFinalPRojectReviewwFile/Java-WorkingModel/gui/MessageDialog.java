package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;

public class MessageDialog extends JDialog {

    public enum Type { INFO, SUCCESS, WARNING, ERROR }

    private boolean confirmed;

    private MessageDialog(Window owner, String title, String message, Type type, String confirmText) {
        super(owner, title, ModalityType.APPLICATION_MODAL);

        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(Color.WHITE);
        root.setBorder(new EmptyBorder(28, 34, 26, 34));

        JLabel text = new JLabel("<html><div style='width:280px'>" + escape(message) + "</div></html>");
        text.setFont(AuthComponents.font(Font.BOLD, 16));
        text.setForeground(AuthComponents.LABEL);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(0, 0, 0, 22);
        root.add(new TypeIcon(type), c);

        c.gridx = 1;
        c.insets = new Insets(0, 0, 0, 0);
        c.anchor = GridBagConstraints.WEST;
        root.add(text, c);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        buttons.setOpaque(false);
        JButton primary;
        if (confirmText == null) {
            primary = new AuthComponents.PrimaryButton("OK", false);
            primary.setPreferredSize(new Dimension(180, 46));
            primary.addActionListener(e -> dispose());
        } else {
            UI.AppButton cancel = new UI.AppButton("Cancel", null, UI.Variant.SECONDARY);
            cancel.setPreferredSize(new Dimension(140, 46));
            cancel.addActionListener(e -> dispose());
            buttons.add(cancel);
            primary = new UI.AppButton(confirmText, null, type == Type.ERROR || type == Type.WARNING ? UI.Variant.DANGER : UI.Variant.PRIMARY);
            primary.setPreferredSize(new Dimension(140, 46));
            primary.addActionListener(e -> {
                confirmed = true;
                dispose();
            });
        }
        buttons.add(primary);

        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(26, 0, 0, 0);
        root.add(buttons, c);

        setContentPane(root);
        getRootPane().setDefaultButton(primary);
        getRootPane().registerKeyboardAction(e -> dispose(),
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        pack();
        setLocationRelativeTo(owner);
        setVisible(true);
    }

    private static Window ownerOf(Component parent) {
        return parent instanceof Window w ? w : parent == null ? null : SwingUtilities.getWindowAncestor(parent);
    }

    public static void show(Component parent, String title, String message, Type type) {
        new MessageDialog(ownerOf(parent), title, message, type, null);
    }

    public static boolean confirm(Component parent, String title, String message, Type type, String confirmText) {
        return new MessageDialog(ownerOf(parent), title, message, type, confirmText).confirmed;
    }

    private static String escape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>");
    }

    private static class TypeIcon extends JComponent {

        private final Type type;

        TypeIcon(Type type) {
            this.type = type;
            setPreferredSize(new Dimension(64, 64));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            Color fill = switch (type) {
                case INFO -> AuthComponents.PRIMARY;
                case SUCCESS -> new Color(22, 163, 74);
                case WARNING -> new Color(245, 158, 11);
                case ERROR -> new Color(220, 38, 38);
            };
            g2.setColor(fill);
            g2.fill(new Ellipse2D.Double(0, 0, 64, 64));

            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(5.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            switch (type) {
                case INFO -> {
                    g2.fill(new Ellipse2D.Double(28, 14, 8, 8));
                    g2.fill(new RoundRectangle2D.Double(28, 26, 8, 24, 5, 5));
                }
                case WARNING -> {
                    g2.fill(new RoundRectangle2D.Double(28, 13, 8, 26, 5, 5));
                    g2.fill(new Ellipse2D.Double(28, 43, 8, 8));
                }
                case SUCCESS -> {
                    Path2D p = new Path2D.Double();
                    p.moveTo(19, 33);
                    p.lineTo(28, 42);
                    p.lineTo(45, 23);
                    g2.draw(p);
                }
                case ERROR -> {
                    g2.draw(new Line2D.Double(22, 22, 42, 42));
                    g2.draw(new Line2D.Double(42, 22, 22, 42));
                }
            }
            g2.dispose();
        }
    }
}
