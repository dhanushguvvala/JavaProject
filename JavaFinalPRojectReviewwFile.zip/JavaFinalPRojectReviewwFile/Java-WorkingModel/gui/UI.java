package gui;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.util.Map;

public final class UI {

    public static final Color BG = new Color(244, 247, 252);
    public static final Color CARD = Color.WHITE;
    public static final Color BORDER = new Color(226, 232, 240);
    public static final Color TEXT = new Color(15, 23, 42);
    public static final Color MUTED = new Color(100, 116, 139);
    public static final Color FAINT = new Color(148, 163, 184);
    public static final Color PRIMARY = AuthComponents.PRIMARY;
    public static final Color PRIMARY_SOFT = new Color(232, 241, 255);
    public static final Color SUCCESS = new Color(22, 163, 74);
    public static final Color DANGER = new Color(220, 38, 38);
    public static final Color WARNING = new Color(217, 119, 6);
    public static final Color PURPLE = new Color(124, 58, 237);
    public static final Color NAVY = AuthComponents.NAVY;
    public static final Color NAVY_DARK = AuthComponents.NAVY_DARK;

    private static final Map<String, Color> CATEGORY_COLORS = Map.ofEntries(
            Map.entry("Food", new Color(234, 88, 12)),
            Map.entry("Rent", new Color(37, 99, 235)),
            Map.entry("Transport", new Color(13, 148, 136)),
            Map.entry("Utilities", new Color(8, 145, 178)),
            Map.entry("Health", new Color(219, 39, 119)),
            Map.entry("Education", new Color(124, 58, 237)),
            Map.entry("Shopping", new Color(217, 119, 6)),
            Map.entry("Entertainment", new Color(192, 38, 211)),
            Map.entry("Other", new Color(100, 116, 139)),
            Map.entry("Salary", new Color(22, 163, 74)),
            Map.entry("Freelance", new Color(5, 150, 105)),
            Map.entry("Business", new Color(21, 128, 61)),
            Map.entry("Investment", new Color(79, 70, 229)),
            Map.entry("Gift", new Color(236, 72, 153))
    );

    private static final Color[] FALLBACK = {
            new Color(37, 99, 235), new Color(234, 88, 12), new Color(13, 148, 136),
            new Color(124, 58, 237), new Color(219, 39, 119), new Color(217, 119, 6)
    };

    private UI() {
    }

    public static Font font(int style, int size) {
        return AuthComponents.font(style, size);
    }

    public static Color categoryColor(String category) {
        Color c = CATEGORY_COLORS.get(category);
        return c != null ? c : FALLBACK[Math.abs(category.hashCode()) % FALLBACK.length];
    }

    public static Color soft(Color c) {
        return mix(c, Color.WHITE, 0.88);
    }

    public static Color mix(Color a, Color b, double t) {
        return new Color(
                (int) (a.getRed() + (b.getRed() - a.getRed()) * t),
                (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * t));
    }

    public static Color scoreColor(int score) {
        if (score >= 70) return SUCCESS;
        if (score >= 55) return new Color(202, 138, 4);
        if (score >= 40) return WARNING;
        return DANGER;
    }

    public static JLabel label(String text, int style, int size, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font(style, size));
        l.setForeground(color);
        return l;
    }

    public static JTextArea wrap(String text, int size, Color color) {
        JTextArea a = new JTextArea(text);
        a.setFont(font(Font.PLAIN, size));
        a.setForeground(color);
        a.setLineWrap(true);
        a.setWrapStyleWord(true);
        a.setEditable(false);
        a.setFocusable(false);
        a.setOpaque(false);
        a.setBorder(null);
        a.setHighlighter(null);
        ((javax.swing.text.DefaultCaret) a.getCaret()).setUpdatePolicy(javax.swing.text.DefaultCaret.NEVER_UPDATE);
        return a;
    }

    public static void paintPill(Graphics2D g2, String text, int x, int cy, Color fg, Color bg, Font f) {
        g2.setFont(f);
        FontMetrics fm = g2.getFontMetrics();
        int w = fm.stringWidth(text) + 20;
        int h = fm.getHeight() + 6;
        g2.setColor(bg);
        g2.fill(new RoundRectangle2D.Double(x, cy - h / 2.0, w, h, h, h));
        g2.setColor(fg);
        g2.drawString(text, x + 10, cy - h / 2 + 3 + fm.getAscent());
    }

    public static class Card extends JPanel {

        public Card(LayoutManager layout) {
            super(layout);
            setOpaque(false);
            setBorder(new EmptyBorder(20, 22, 20, 22));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            Shape s = new RoundRectangle2D.Double(0.5, 0.5, getWidth() - 1, getHeight() - 1, 16, 16);
            g2.setColor(CARD);
            g2.fill(s);
            g2.setColor(BORDER);
            g2.draw(s);
            g2.dispose();
        }
    }

    public static JPanel cardHeader(String title, String subtitle, JComponent right) {
        JPanel p = new JPanel(new BorderLayout(12, 0));
        p.setOpaque(false);
        JPanel texts = new JPanel(new GridLayout(subtitle == null ? 1 : 2, 1, 0, 2));
        texts.setOpaque(false);
        texts.add(label(title, Font.BOLD, 17, TEXT));
        if (subtitle != null) {
            texts.add(label(subtitle, Font.PLAIN, 13, MUTED));
        }
        p.add(texts, BorderLayout.CENTER);
        if (right != null) {
            JPanel r = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
            r.setOpaque(false);
            r.add(right);
            p.add(r, BorderLayout.EAST);
        }
        p.setBorder(new EmptyBorder(0, 0, 14, 0));
        return p;
    }

    public enum Variant { PRIMARY, SECONDARY, DANGER, GHOST, LINK }

    public static class AppButton extends JButton {

        private final Icons.Type icon;
        private final Variant variant;

        public AppButton(String text, Icons.Type icon, Variant variant) {
            super(text);
            this.icon = icon;
            this.variant = variant;
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setRolloverEnabled(true);
            setFont(font(Font.BOLD, 14));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            FontMetrics fm = getFontMetrics(getFont());
            int w = fm.stringWidth(text) + (icon != null ? 28 : 0) + (variant == Variant.LINK ? 4 : 36);
            setPreferredSize(new Dimension(w, variant == Variant.LINK ? 28 : 40));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            ButtonModel m = getModel();
            boolean hover = m.isRollover() && isEnabled();
            boolean pressed = m.isPressed();
            Shape box = new RoundRectangle2D.Double(0.5, 0.5, getWidth() - 1, getHeight() - 1, 10, 10);
            Color fg;
            switch (variant) {
                case PRIMARY -> {
                    g2.setColor(pressed ? AuthComponents.PRIMARY_PRESSED : hover ? AuthComponents.PRIMARY_HOVER : PRIMARY);
                    g2.fill(box);
                    fg = Color.WHITE;
                }
                case DANGER -> {
                    g2.setColor(pressed ? new Color(170, 30, 30) : hover ? new Color(195, 32, 32) : DANGER);
                    g2.fill(box);
                    fg = Color.WHITE;
                }
                case SECONDARY -> {
                    g2.setColor(hover ? new Color(248, 250, 252) : Color.WHITE);
                    g2.fill(box);
                    g2.setColor(hover ? new Color(203, 213, 225) : BORDER);
                    g2.draw(box);
                    fg = TEXT;
                }
                case GHOST -> {
                    if (hover) {
                        g2.setColor(new Color(241, 245, 249));
                        g2.fill(box);
                    }
                    fg = MUTED;
                }
                default -> fg = hover ? AuthComponents.PRIMARY_HOVER : PRIMARY;
            }
            if (!isEnabled()) {
                fg = FAINT;
            }
            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            int textW = fm.stringWidth(getText());
            int total = textW + (icon != null ? 26 : 0);
            int x = (getWidth() - total) / 2;
            if (icon != null) {
                Icons.paint(g2, icon, x, (getHeight() - 18) / 2.0, 18, fg);
                x += 26;
            }
            g2.setColor(fg);
            g2.drawString(getText(), x, (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }
    }

    public static class IconButton extends JButton {

        private final Icons.Type icon;

        public IconButton(Icons.Type icon, String tooltip) {
            this.icon = icon;
            setToolTipText(tooltip);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setRolloverEnabled(true);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(40, 40));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            Shape box = new RoundRectangle2D.Double(0.5, 0.5, getWidth() - 1, getHeight() - 1, 10, 10);
            g2.setColor(getModel().isRollover() ? new Color(248, 250, 252) : Color.WHITE);
            g2.fill(box);
            g2.setColor(BORDER);
            g2.draw(box);
            Icons.paint(g2, icon, (getWidth() - 18) / 2.0, (getHeight() - 18) / 2.0, 18, isEnabled() ? TEXT : FAINT);
            g2.dispose();
        }
    }

    public static class RoundBorder extends AbstractBorder {

        private final Insets insets;

        public RoundBorder(Insets insets) {
            this.insets = insets;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = AuthComponents.smooth(g);
            boolean focus = c.isFocusOwner() || (c instanceof JComboBox<?> cb && cb.isPopupVisible());
            g2.setColor(focus ? PRIMARY : BORDER);
            g2.setStroke(new BasicStroke(focus ? 1.6f : 1f));
            g2.draw(new RoundRectangle2D.Double(x + 0.8, y + 0.8, w - 1.6, h - 1.6, 10, 10));
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return insets;
        }
    }

    public static class InputField extends JPanel {

        private final JTextComponent input;
        private final Icons.Type icon;
        private final String prefix;

        public InputField(JTextComponent input, Icons.Type icon, String prefix) {
            super(new BorderLayout());
            this.input = input;
            this.icon = icon;
            this.prefix = prefix;
            setOpaque(false);
            int left = icon != null ? 42 : prefix != null ? 34 : 14;
            setBorder(new EmptyBorder(0, left, 0, 12));
            setPreferredSize(new Dimension(220, 42));
            setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
            input.setBorder(null);
            input.setOpaque(false);
            input.setFont(font(Font.PLAIN, 15));
            input.setForeground(TEXT);
            input.setCaretColor(PRIMARY);
            input.setSelectionColor(new Color(191, 219, 254));
            add(input, BorderLayout.CENTER);
            input.addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    repaint();
                }

                @Override
                public void focusLost(FocusEvent e) {
                    repaint();
                }
            });
            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    input.requestFocusInWindow();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            boolean focus = input.isFocusOwner();
            Shape box = new RoundRectangle2D.Double(0.8, 0.8, getWidth() - 1.6, getHeight() - 1.6, 10, 10);
            g2.setColor(Color.WHITE);
            g2.fill(box);
            g2.setColor(focus ? PRIMARY : BORDER);
            g2.setStroke(new BasicStroke(focus ? 1.6f : 1f));
            g2.draw(box);
            if (icon != null) {
                Icons.paint(g2, icon, 14, (getHeight() - 18) / 2.0, 18, focus ? PRIMARY : FAINT);
            } else if (prefix != null) {
                g2.setFont(font(Font.BOLD, 15));
                g2.setColor(MUTED);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(prefix, 14, (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
            }
            g2.dispose();
        }
    }

    public static <E> JComboBox<E> combo(E[] items) {
        JComboBox<E> box = new JComboBox<>(items);
        styleCombo(box);
        return box;
    }

    public static void styleCombo(JComboBox<?> box) {
        box.setUI(new FlatComboUI());
        box.setFont(font(Font.PLAIN, 14));
        box.setForeground(TEXT);
        box.setBackground(Color.WHITE);
        box.setOpaque(false);
        box.setBorder(new RoundBorder(new Insets(2, 10, 2, 4)));
        box.setPreferredSize(new Dimension(Math.max(box.getPreferredSize().width + 20, 150), 42));
        box.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        box.setMaximumRowCount(12);
        ListCellRenderer<Object> base = new DefaultListCellRenderer();
        box.setRenderer((list, value, index, selected, focus) -> {
            JLabel l = (JLabel) base.getListCellRendererComponent(list, value, index, selected, focus);
            l.setFont(font(Font.PLAIN, 14));
            l.setBorder(new EmptyBorder(8, 10, 8, 10));
            l.setBackground(selected ? PRIMARY_SOFT : Color.WHITE);
            l.setForeground(selected ? PRIMARY : TEXT);
            if (index == -1) {
                l.setBorder(new EmptyBorder(0, 2, 0, 0));
                l.setOpaque(false);
                l.setForeground(TEXT);
            }
            return l;
        });
    }

    private static class FlatComboUI extends BasicComboBoxUI {

        @Override
        protected JButton createArrowButton() {
            JButton b = new JButton() {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2 = AuthComponents.smooth(g);
                    Icons.paint(g2, Icons.Type.CHEVRON_DOWN, (getWidth() - 16) / 2.0, (getHeight() - 16) / 2.0, 16, MUTED);
                    g2.dispose();
                }
            };
            b.setBorder(null);
            b.setContentAreaFilled(false);
            b.setFocusPainted(false);
            b.setOpaque(false);
            b.setPreferredSize(new Dimension(30, 30));
            return b;
        }

        @Override
        public void paint(Graphics g, JComponent c) {
            Graphics2D g2 = AuthComponents.smooth(g);
            g2.setColor(Color.WHITE);
            g2.fill(new RoundRectangle2D.Double(0.8, 0.8, c.getWidth() - 1.6, c.getHeight() - 1.6, 10, 10));
            g2.dispose();
            super.paint(g, c);
        }

        @Override
        public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) {
        }

        @Override
        protected javax.swing.plaf.basic.ComboPopup createPopup() {
            javax.swing.plaf.basic.BasicComboPopup popup = new javax.swing.plaf.basic.BasicComboPopup(comboBox);
            popup.setBorder(BorderFactory.createLineBorder(BORDER));
            return popup;
        }
    }

    public static class ScrollablePanel extends JPanel implements Scrollable {

        private boolean pending;
        private boolean second;

        public ScrollablePanel(LayoutManager layout) {
            super(layout);
        }

        @Override
        public void doLayout() {
            super.doLayout();
            if (second) {
                second = false;
                return;
            }
            if (!pending) {
                pending = true;
                SwingUtilities.invokeLater(() -> {
                    pending = false;
                    second = true;
                    invalidateTree(this);
                    revalidate();
                    repaint();
                });
            }
        }

        private static void invalidateTree(Container c) {
            c.invalidate();
            for (Component child : c.getComponents()) {
                if (child instanceof Container cc) {
                    invalidateTree(cc);
                }
            }
        }

        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return getPreferredSize();
        }

        @Override
        public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
            return 24;
        }

        @Override
        public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
            return visibleRect.height - 48;
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return getParent() instanceof JViewport v && v.getHeight() > getPreferredSize().height;
        }
    }

    public static JScrollPane scroll(Component view) {
        JScrollPane sp = new JScrollPane(view);
        sp.setBorder(null);
        sp.setViewportBorder(null);
        sp.getViewport().setOpaque(false);
        sp.setOpaque(false);
        sp.getVerticalScrollBar().setUnitIncrement(24);
        sp.getVerticalScrollBar().setUI(new SlimScrollBarUI());
        sp.getHorizontalScrollBar().setUI(new SlimScrollBarUI());
        sp.getVerticalScrollBar().setPreferredSize(new Dimension(10, 0));
        sp.getVerticalScrollBar().setOpaque(false);
        sp.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        return sp;
    }

    private static class SlimScrollBarUI extends BasicScrollBarUI {

        @Override
        protected void configureScrollBarColors() {
            thumbColor = new Color(203, 213, 225);
            trackColor = new Color(0, 0, 0, 0);
        }

        @Override
        protected JButton createDecreaseButton(int orientation) {
            return zero();
        }

        @Override
        protected JButton createIncreaseButton(int orientation) {
            return zero();
        }

        private JButton zero() {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            return b;
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            if (r.isEmpty()) {
                return;
            }
            Graphics2D g2 = AuthComponents.smooth(g);
            g2.setColor(isDragging ? new Color(148, 163, 184) : thumbColor);
            g2.fill(new RoundRectangle2D.Double(r.x + 2, r.y + 2, r.width - 4, r.height - 4, 6, 6));
            g2.dispose();
        }
    }

    public static void styleTable(JTable table) {
        table.setRowHeight(46);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFont(font(Font.PLAIN, 14));
        table.setForeground(TEXT);
        table.setBackground(Color.WHITE);
        table.setSelectionBackground(PRIMARY_SOFT);
        table.setSelectionForeground(TEXT);
        table.setFillsViewportHeight(true);
        table.setFocusable(true);
        table.setAutoCreateRowSorter(false);
        JTableHeader header = table.getTableHeader();
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 40));
        header.setDefaultRenderer((t, value, sel, focus, row, col) -> {
            JLabel l = new JLabel(value == null ? "" : value.toString().toUpperCase());
            l.setFont(font(Font.BOLD, 12));
            l.setForeground(MUTED);
            l.setOpaque(true);
            l.setBackground(new Color(248, 250, 252));
            l.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER), new EmptyBorder(0, 16, 0, 16)));
            int align = t.getColumnModel().getColumn(col).getCellRenderer() instanceof CellRenderer cr ? cr.align : SwingConstants.LEFT;
            l.setHorizontalAlignment(align);
            return l;
        });
    }

    public static class CellRenderer extends DefaultTableCellRenderer {

        final int align;

        public CellRenderer(int align) {
            this.align = align;
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focus, int row, int col) {
            super.getTableCellRendererComponent(table, value, selected, false, row, col);
            setHorizontalAlignment(align);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(241, 245, 249)), new EmptyBorder(0, 16, 0, 16)));
            setFont(font(Font.PLAIN, 14));
            setForeground(TEXT);
            setBackground(selected ? PRIMARY_SOFT : Color.WHITE);
            return this;
        }
    }

    public static class Progress extends JComponent {

        private double ratio;
        private Color color = PRIMARY;

        public Progress() {
            setPreferredSize(new Dimension(120, 8));
        }

        public void set(double ratio, Color color) {
            this.ratio = ratio;
            this.color = color;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            int h = getHeight();
            g2.setColor(new Color(237, 241, 247));
            g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), h, h, h));
            double w = getWidth() * Math.max(0, Math.min(1, ratio));
            if (w > 0) {
                g2.setColor(color);
                g2.fill(new RoundRectangle2D.Double(0, 0, Math.max(w, h), h, h, h));
            }
            g2.dispose();
        }
    }

    public static class IconBadge extends JComponent {

        private final Icons.Type icon;
        private final Color color;
        private final int size;

        public IconBadge(Icons.Type icon, Color color, int size) {
            this.icon = icon;
            this.color = color;
            this.size = size;
            setPreferredSize(new Dimension(size, size));
            setMinimumSize(new Dimension(size, size));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            g2.setColor(soft(color));
            g2.fill(new RoundRectangle2D.Double(0, 0, size, size, size * 0.34, size * 0.34));
            double is = size * 0.5;
            Icons.paint(g2, icon, (size - is) / 2, (size - is) / 2, is, color);
            g2.dispose();
        }
    }

    public static class Dot extends JComponent {

        private final Color color;

        public Dot(Color color) {
            this.color = color;
            setPreferredSize(new Dimension(10, 10));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            g2.setColor(color);
            g2.fill(new Ellipse2D.Double(0, (getHeight() - 10) / 2.0, 10, 10));
            g2.dispose();
        }
    }

    public static class StatCard extends Card {

        private final JLabel value = label("-", Font.BOLD, 26, TEXT);
        private final JLabel sub = label(" ", Font.PLAIN, 13, MUTED);

        public StatCard(String title, Icons.Type icon, Color color) {
            super(new BorderLayout(14, 0));
            setBorder(new EmptyBorder(18, 20, 18, 20));
            JPanel texts = new JPanel(new GridLayout(3, 1, 0, 2));
            texts.setOpaque(false);
            texts.add(label(title, Font.BOLD, 13, MUTED));
            texts.add(value);
            texts.add(sub);
            JPanel badge = new JPanel(new BorderLayout());
            badge.setOpaque(false);
            badge.add(new IconBadge(icon, color, 44), BorderLayout.NORTH);
            add(texts, BorderLayout.CENTER);
            add(badge, BorderLayout.EAST);
        }

        public void set(String v, Color valueColor, String subText, Color subColor) {
            value.setText(v);
            value.setForeground(valueColor);
            sub.setText(subText == null || subText.isEmpty() ? " " : subText);
            sub.setForeground(subColor);
        }
    }

    public static JPanel emptyState(Icons.Type icon, String title, String text) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        p.add(new IconBadge(icon, FAINT, 48), c);
        c.gridy = 1;
        c.insets = new Insets(12, 0, 4, 0);
        p.add(label(title, Font.BOLD, 15, TEXT), c);
        c.gridy = 2;
        c.insets = new Insets(0, 0, 0, 0);
        p.add(label(text, Font.PLAIN, 13, MUTED), c);
        p.setBorder(new EmptyBorder(24, 0, 24, 0));
        return p;
    }

    public static GridBagConstraints gbc(int x, int y, int w, double weightx, double weighty, Insets insets) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = x;
        c.gridy = y;
        c.gridwidth = w;
        c.weightx = weightx;
        c.weighty = weighty;
        c.fill = GridBagConstraints.BOTH;
        c.insets = insets;
        return c;
    }
}
