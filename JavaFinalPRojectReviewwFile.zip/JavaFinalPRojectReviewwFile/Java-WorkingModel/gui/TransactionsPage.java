package gui;

import model.Categories;
import model.Transaction;
import util.Money;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;
import java.util.List;

public class TransactionsPage extends Page {

    private static final String ALL_TYPES = "All types";
    private static final String ALL_CATEGORIES = "All categories";
    private static final String THIS_MONTH = "Selected month";
    private static final String ALL_MONTHS = "All months";

    private final AuthComponents.HintTextField search = new AuthComponents.HintTextField("Search description or category");
    private final JComboBox<String> typeBox = UI.combo(new String[]{ALL_TYPES, "Income", "Expense"});
    private final JComboBox<String> categoryBox = UI.combo(allCategories());
    private final JComboBox<String> scopeBox = UI.combo(new String[]{THIS_MONTH, ALL_MONTHS});
    private final DefaultTableModel model;
    private final JTable table;
    private final JLabel footer = UI.label(" ", Font.PLAIN, 13, UI.MUTED);
    private final JLabel tableTitle = UI.label(" ", Font.BOLD, 17, UI.TEXT);
    private final List<Transaction> shown = new ArrayList<>();

    public TransactionsPage(AppContext ctx) {
        super(ctx);

        model = new DefaultTableModel(new Object[]{"Date", "Description", "Category", "Type", "Amount"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int c) {
                return switch (c) {
                    case 0 -> LocalDate.class;
                    case 4 -> Double.class;
                    default -> String.class;
                };
            }
        };

        table = new JTable(model);
        UI.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);
        sorter.setSortKeys(List.of(new RowSorter.SortKey(0, SortOrder.DESCENDING)));

        table.getColumnModel().getColumn(0).setCellRenderer(new UI.CellRenderer(SwingConstants.LEFT) {
            @Override
            protected void setValue(Object value) {
                setText(value instanceof LocalDate d ? AppContext.DATE.format(d) : "");
                setForeground(UI.MUTED);
            }
        });
        table.getColumnModel().getColumn(1).setCellRenderer(new UI.CellRenderer(SwingConstants.LEFT) {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
                super.getTableCellRendererComponent(t, v, s, f, r, c);
                setFont(UI.font(Font.BOLD, 14));
                return this;
            }
        });
        table.getColumnModel().getColumn(2).setCellRenderer(new PillRenderer(true));
        table.getColumnModel().getColumn(3).setCellRenderer(new PillRenderer(false));
        table.getColumnModel().getColumn(4).setCellRenderer(new UI.CellRenderer(SwingConstants.RIGHT) {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
                super.getTableCellRendererComponent(t, v, s, f, r, c);
                boolean income = "Income".equals(t.getValueAt(r, 3));
                setText(Money.signed((Double) v, income));
                setFont(UI.font(Font.BOLD, 14));
                setForeground(income ? UI.SUCCESS : UI.TEXT);
                return this;
            }
        });
        int[] widths = {130, 300, 150, 120, 140};
        for (int i = 0; i < widths.length; i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }

        JPopupMenu menu = new JPopupMenu();
        menu.setBorder(BorderFactory.createLineBorder(UI.BORDER));
        JMenuItem editItem = menuItem("Edit", Icons.Type.EDIT, UI.TEXT);
        JMenuItem deleteItem = menuItem("Delete", Icons.Type.TRASH, UI.DANGER);
        editItem.addActionListener(e -> editSelected());
        deleteItem.addActionListener(e -> deleteSelected());
        menu.add(editItem);
        menu.add(deleteItem);

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                popup(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                popup(e);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                    editSelected();
                }
            }

            private void popup(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    int r = table.rowAtPoint(e.getPoint());
                    if (r >= 0) {
                        table.setRowSelectionInterval(r, r);
                        menu.show(table, e.getX(), e.getY());
                    }
                }
            }
        });

        UI.InputField searchField = new UI.InputField(search, Icons.Type.SEARCH, null);
        searchField.setPreferredSize(new Dimension(300, 42));
        search.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                refresh();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                refresh();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                refresh();
            }
        });
        typeBox.addActionListener(e -> refresh());
        categoryBox.addActionListener(e -> refresh());
        scopeBox.addActionListener(e -> refresh());

        UI.Card toolbar = new UI.Card(new BorderLayout(16, 0));
        toolbar.setBorder(new EmptyBorder(14, 16, 14, 16));
        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        filters.setOpaque(false);
        filters.add(searchField);
        filters.add(typeBox);
        filters.add(categoryBox);
        filters.add(scopeBox);
        toolbar.add(filters, BorderLayout.CENTER);
        addRow(toolbar, 0);

        UI.AppButton edit = new UI.AppButton("Edit", Icons.Type.EDIT, UI.Variant.SECONDARY);
        UI.AppButton delete = new UI.AppButton("Delete", Icons.Type.TRASH, UI.Variant.SECONDARY);
        UI.AppButton export = new UI.AppButton("Export CSV", Icons.Type.DOWNLOAD, UI.Variant.SECONDARY);
        edit.addActionListener(e -> editSelected());
        delete.addActionListener(e -> deleteSelected());
        export.addActionListener(e -> export());
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actions.setOpaque(false);
        actions.add(edit);
        actions.add(delete);
        actions.add(export);

        JPanel head = new JPanel(new BorderLayout());
        head.setOpaque(false);
        head.setBorder(new EmptyBorder(18, 22, 14, 22));
        JPanel titles = new JPanel(new GridLayout(2, 1, 0, 2));
        titles.setOpaque(false);
        titles.add(tableTitle);
        titles.add(footer);
        head.add(titles, BorderLayout.CENTER);
        head.add(actions, BorderLayout.EAST);

        JScrollPane sp = UI.scroll(table);
        sp.getViewport().setBackground(Color.WHITE);
        sp.getViewport().setOpaque(true);
        sp.setPreferredSize(new Dimension(400, 300));
        sp.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UI.BORDER));

        UI.Card tableCard = new UI.Card(new BorderLayout());
        tableCard.setBorder(new EmptyBorder(0, 1, 14, 1));
        tableCard.add(head, BorderLayout.NORTH);
        tableCard.add(sp, BorderLayout.CENTER);
        addRow(tableCard, 1);
    }

    private static String[] allCategories() {
        Set<String> set = new LinkedHashSet<>();
        set.add(ALL_CATEGORIES);
        set.addAll(Arrays.asList(Categories.EXPENSE));
        set.addAll(Arrays.asList(Categories.INCOME));
        return set.toArray(new String[0]);
    }

    private static JMenuItem menuItem(String text, Icons.Type icon, Color color) {
        JMenuItem item = new JMenuItem(text, Icons.of(icon, 16, color));
        item.setFont(UI.font(Font.PLAIN, 14));
        item.setForeground(color);
        item.setBackground(Color.WHITE);
        item.setIconTextGap(10);
        item.setBorder(new EmptyBorder(8, 12, 8, 24));
        return item;
    }

    @Override
    public String title() {
        return "Transactions";
    }

    @Override
    public String subtitle() {
        return "Double-click a row to edit it, or right-click for more options";
    }

    @Override
    public boolean scrolls() {
        return false;
    }

    @Override
    public void refresh() {
        String q = search.getText().trim().toLowerCase(Locale.ENGLISH);
        String type = (String) typeBox.getSelectedItem();
        String cat = (String) categoryBox.getSelectedItem();
        boolean allMonths = ALL_MONTHS.equals(scopeBox.getSelectedItem());

        shown.clear();
        for (Transaction t : ctx.transactions.getTransactions()) {
            if (!allMonths && !t.getMonth().equals(ctx.getMonth())) continue;
            if (!ALL_TYPES.equals(type) && !t.getType().equalsIgnoreCase(type)) continue;
            if (!ALL_CATEGORIES.equals(cat) && !t.getCategory().equals(cat)) continue;
            if (!q.isEmpty() && !(t.getDescription().toLowerCase(Locale.ENGLISH).contains(q)
                    || t.getCategory().toLowerCase(Locale.ENGLISH).contains(q))) continue;
            shown.add(t);
        }

        model.setRowCount(0);
        double in = 0;
        double out = 0;
        for (Transaction t : shown) {
            model.addRow(new Object[]{t.getDate(), t.getDescription(), t.getCategory(), t.getType(), t.getAmount()});
            if (t.isIncome()) in += t.getAmount();
            else out += t.getAmount();
        }
        tableTitle.setText(allMonths ? "All transactions" : AppContext.MONTH.format(ctx.getMonth()));
        footer.setText(shown.size() + (shown.size() == 1 ? " transaction" : " transactions")
                + "   \u2022   Income " + Money.format(in) + "   \u2022   Expenses " + Money.format(out));
    }

    private Transaction selected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            MessageDialog.show(this, "No Selection", "Select a transaction in the table first.", MessageDialog.Type.INFO);
            return null;
        }
        return shown.get(table.convertRowIndexToModel(row));
    }

    private void editSelected() {
        Transaction t = selected();
        if (t != null) {
            ctx.editTransaction(this, t.getId());
        }
    }

    private void deleteSelected() {
        Transaction t = selected();
        if (t != null) {
            ctx.deleteTransaction(this, t.getId());
        }
    }

    private void export() {
        if (shown.isEmpty()) {
            MessageDialog.show(this, "Nothing to Export", "There are no transactions in the current view.", MessageDialog.Type.INFO);
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File(ctx.username + "_transactions.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase(Locale.ENGLISH).endsWith(".csv")) {
            file = new File(file.getParentFile(), file.getName() + ".csv");
        }
        try (Writer w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
            w.write('\uFEFF');
            w.write("Date,Description,Category,Type,Amount\n");
            for (Transaction t : shown) {
                w.write(t.getDate() + "," + csv(t.getDescription()) + "," + csv(t.getCategory()) + ","
                        + t.getType() + "," + String.format(Locale.ENGLISH, "%.2f", t.getAmount()) + "\n");
            }
            MessageDialog.show(this, "Export Complete", shown.size() + " transactions exported to " + file.getName() + ".", MessageDialog.Type.SUCCESS);
        } catch (IOException e) {
            MessageDialog.show(this, "Export Failed", "Couldn't write the file: " + e.getMessage(), MessageDialog.Type.ERROR);
        }
    }

    private static String csv(String s) {
        return s.contains(",") || s.contains("\"") ? "\"" + s.replace("\"", "\"\"") + "\"" : s;
    }

    private static class PillRenderer extends JComponent implements TableCellRenderer {

        private final boolean category;
        private String text = "";
        private boolean selected;

        PillRenderer(boolean category) {
            this.category = category;
        }

        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
            text = v == null ? "" : v.toString();
            selected = s;
            return this;
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            g2.setColor(selected ? UI.PRIMARY_SOFT : Color.WHITE);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setColor(new Color(241, 245, 249));
            g2.fillRect(0, getHeight() - 1, getWidth(), 1);
            Color c = category ? UI.categoryColor(text) : "Income".equals(text) ? UI.SUCCESS : UI.DANGER;
            UI.paintPill(g2, text, 16, getHeight() / 2, UI.mix(c, Color.BLACK, 0.15), UI.soft(c), UI.font(Font.BOLD, 12));
            g2.dispose();
        }
    }
}
