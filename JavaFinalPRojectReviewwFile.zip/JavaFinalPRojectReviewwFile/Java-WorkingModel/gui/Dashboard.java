package gui;

import util.Session;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Dashboard extends JFrame {

    private final AppContext ctx;
    private final Map<String, Page> pages = new LinkedHashMap<>();
    private final Map<String, JScrollPane> scrolls = new LinkedHashMap<>();
    private final Map<String, NavItem> navItems = new LinkedHashMap<>();
    private final CardLayout cards = new CardLayout();
    private final JPanel content = new JPanel(cards);
    private final JLabel pageTitle = UI.label(" ", Font.BOLD, 24, UI.TEXT);
    private final JLabel pageSubtitle = UI.label(" ", Font.PLAIN, 14, UI.MUTED);
    private final JComboBox<YearMonth> monthBox = new JComboBox<>();
    private String current = "overview";
    private boolean updatingMonths;

    public Dashboard(String username) {
        ctx = new AppContext(username);
        ctx.setNavigator(this::show);

        setTitle("Personal Finance Tracker - " + username);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        pages.put("overview", new OverviewPage(ctx));
        pages.put("transactions", new TransactionsPage(ctx));
        pages.put("monthly", new MonthlyReportPage(ctx));
        pages.put("analysis", new AnalysisPage(ctx));
        pages.put("budgets", new BudgetsPage(ctx));

        content.setBackground(UI.BG);
        for (Map.Entry<String, Page> e : pages.entrySet()) {
            Page p = e.getValue();
            if (p.scrolls()) {
                JScrollPane sp = UI.scroll(p);
                sp.getViewport().setOpaque(true);
                sp.getViewport().setBackground(UI.BG);
                scrolls.put(e.getKey(), sp);
                content.add(sp, e.getKey());
            } else {
                content.add(p, e.getKey());
            }
        }

        UI.styleCombo(monthBox);
        monthBox.setPreferredSize(new Dimension(200, 42));
        monthBox.setRenderer(monthRenderer());
        monthBox.addActionListener(e -> {
            if (!updatingMonths && monthBox.getSelectedItem() instanceof YearMonth ym) {
                ctx.setMonth(ym);
            }
        });

        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(UI.BG);
        main.add(topBar(), BorderLayout.NORTH);
        main.add(content, BorderLayout.CENTER);

        JPanel root = new JPanel(new BorderLayout());
        root.add(sidebar(), BorderLayout.WEST);
        root.add(main, BorderLayout.CENTER);
        setContentPane(root);

        ctx.onChange(this::refreshAll);

        getRootPane().registerKeyboardAction(e -> ctx.addTransaction(this),
                KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK), JComponent.WHEN_IN_FOCUSED_WINDOW);

        refreshAll();
        show("overview");

        setSize(1400, 860);
        setMinimumSize(new Dimension(1200, 760));
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void refreshAll() {
        updatingMonths = true;
        List<YearMonth> months = new ArrayList<>(ctx.transactions.getMonthRange());
        if (!months.contains(ctx.getMonth())) {
            months.add(ctx.getMonth());
            months.sort(Comparator.reverseOrder());
        }
        monthBox.setModel(new DefaultComboBoxModel<>(months.toArray(new YearMonth[0])));
        monthBox.setSelectedItem(ctx.getMonth());
        updatingMonths = false;
        for (Page p : pages.values()) {
            p.refresh();
        }
        updateHeader();
    }

    private void show(String key) {
        JScrollPane sp = scrolls.get(key);
        if (sp != null && !key.equals(current)) {
            sp.getViewport().setViewPosition(new Point(0, 0));
        }
        current = key;
        cards.show(content, key);
        navItems.forEach((k, v) -> v.setSelected(k.equals(key)));
        updateHeader();
    }

    private void updateHeader() {
        Page p = pages.get(current);
        pageTitle.setText(p.title());
        pageSubtitle.setText(p.subtitle());
    }

    private JPanel topBar() {
        JPanel bar = new JPanel(new BorderLayout(20, 0));
        bar.setBackground(Color.WHITE);
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UI.BORDER), new EmptyBorder(18, 28, 18, 28)));
        JPanel titles = new JPanel(new GridLayout(2, 1, 0, 2));
        titles.setOpaque(false);
        titles.add(pageTitle);
        titles.add(pageSubtitle);
        bar.add(titles, BorderLayout.CENTER);

        UI.IconButton prev = new UI.IconButton(Icons.Type.CHEVRON_LEFT, "Previous month");
        UI.IconButton next = new UI.IconButton(Icons.Type.CHEVRON_RIGHT, "Next month");
        prev.addActionListener(e -> ctx.setMonth(ctx.getMonth().minusMonths(1)));
        next.addActionListener(e -> ctx.setMonth(ctx.getMonth().plusMonths(1)));
        UI.AppButton add = new UI.AppButton("Add transaction", Icons.Type.PLUS, UI.Variant.PRIMARY);
        add.setPreferredSize(new Dimension(add.getPreferredSize().width, 42));
        add.setToolTipText("Ctrl+N");
        add.addActionListener(e -> ctx.addTransaction(this));

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        right.add(prev);
        right.add(monthBox);
        right.add(next);
        right.add(Box.createHorizontalStrut(12));
        right.add(add);
        JPanel wrap = new JPanel(new GridBagLayout());
        wrap.setOpaque(false);
        wrap.add(right);
        bar.add(wrap, BorderLayout.EAST);
        return bar;
    }

    private static ListCellRenderer<Object> monthRenderer() {
        DefaultListCellRenderer base = new DefaultListCellRenderer();
        return (list, value, index, selected, focus) -> {
            String text = value instanceof YearMonth ym ? AppContext.MONTH.format(ym) : "";
            JLabel l = (JLabel) base.getListCellRendererComponent(list, text, index, selected, focus);
            l.setFont(UI.font(index == -1 ? Font.BOLD : Font.PLAIN, 14));
            if (index == -1) {
                l.setIcon(Icons.of(Icons.Type.CALENDAR, 18, UI.PRIMARY));
                l.setIconTextGap(10);
                l.setOpaque(false);
                l.setForeground(UI.TEXT);
                l.setBorder(new EmptyBorder(0, 2, 0, 0));
            } else {
                l.setIcon(null);
                l.setBorder(new EmptyBorder(8, 12, 8, 12));
                l.setBackground(selected ? UI.PRIMARY_SOFT : Color.WHITE);
                l.setForeground(selected ? UI.PRIMARY : UI.TEXT);
            }
            return l;
        };
    }

    private JPanel sidebar() {
        JPanel side = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, UI.NAVY, 0, getHeight(), UI.NAVY_DARK));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        side.setPreferredSize(new Dimension(250, 0));
        side.setBorder(new EmptyBorder(22, 16, 20, 16));

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setOpaque(false);
        top.add(brand());
        top.add(Box.createVerticalStrut(30));
        top.add(section("MENU"));
        addNav(top, "overview", "Dashboard", Icons.Type.DASHBOARD);
        addNav(top, "transactions", "Transactions", Icons.Type.LIST);
        addNav(top, "monthly", "Monthly report", Icons.Type.CALENDAR);
        top.add(Box.createVerticalStrut(18));
        top.add(section("INSIGHTS"));
        addNav(top, "analysis", "AI analysis", Icons.Type.SPARKLE);
        addNav(top, "budgets", "Budgets", Icons.Type.TARGET);
        side.add(top, BorderLayout.NORTH);

        JPanel bottom = new JPanel();
        bottom.setLayout(new BoxLayout(bottom, BoxLayout.Y_AXIS));
        bottom.setOpaque(false);
        bottom.add(userChip());
        bottom.add(Box.createVerticalStrut(10));
        bottom.add(new NavItem("Log out", Icons.Type.LOGOUT, this::logout));
        side.add(bottom, BorderLayout.SOUTH);
        return side;
    }

    private void addNav(JPanel panel, String key, String text, Icons.Type icon) {
        NavItem item = new NavItem(text, icon, () -> show(key));
        navItems.put(key, item);
        panel.add(item);
        panel.add(Box.createVerticalStrut(4));
    }

    private void logout() {
        if (MessageDialog.confirm(this, "Log Out", "Log out of " + ctx.username + "?", MessageDialog.Type.INFO, "Log out")) {
            Session.clear();
            dispose();
            new LoginFrame();
        }
    }

    private static JComponent section(String text) {
        JLabel l = UI.label(text, Font.BOLD, 11, new Color(125, 150, 195));
        l.setBorder(new EmptyBorder(0, 14, 8, 0));
        l.setAlignmentX(LEFT_ALIGNMENT);
        l.setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));
        return l;
    }

    private static JComponent brand() {
        JComponent c = new JComponent() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = AuthComponents.smooth(g);
                g2.setColor(AuthComponents.PRIMARY);
                g2.fill(new RoundRectangle2D.Double(6, 2, 42, 42, 12, 12));
                Font rupee = UI.font(Font.BOLD, 22);
                if (!rupee.canDisplay('\u20B9')) {
                    rupee = new Font(Font.SANS_SERIF, Font.BOLD, 22);
                }
                g2.setFont(rupee);
                g2.setColor(Color.WHITE);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString("\u20B9", 27 - fm.stringWidth("\u20B9") / 2, 23 - fm.getHeight() / 2 + fm.getAscent());
                g2.setFont(UI.font(Font.BOLD, 17));
                g2.drawString("Finance Tracker", 60, 20);
                g2.setFont(UI.font(Font.PLAIN, 12));
                g2.setColor(new Color(160, 182, 220));
                g2.drawString("Personal AI assistant", 60, 38);
                g2.dispose();
            }
        };
        c.setPreferredSize(new Dimension(218, 46));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        c.setAlignmentX(LEFT_ALIGNMENT);
        return c;
    }

    private JComponent userChip() {
        String name = ctx.username;
        JComponent c = new JComponent() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = AuthComponents.smooth(g);
                g2.setColor(new Color(255, 255, 255, 16));
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 14, 14));
                g2.setColor(new Color(59, 130, 246));
                g2.fill(new Ellipse2D.Double(12, 12, 38, 38));
                g2.setColor(Color.WHITE);
                g2.setFont(UI.font(Font.BOLD, 17));
                FontMetrics fm = g2.getFontMetrics();
                String initial = name.substring(0, 1).toUpperCase();
                g2.drawString(initial, 31 - fm.stringWidth(initial) / 2, 31 - fm.getHeight() / 2 + fm.getAscent());
                g2.setFont(UI.font(Font.BOLD, 14));
                g2.drawString(name, 62, 29);
                g2.setFont(UI.font(Font.PLAIN, 12));
                g2.setColor(new Color(160, 182, 220));
                g2.drawString("Personal account", 62, 46);
                g2.dispose();
            }
        };
        c.setPreferredSize(new Dimension(218, 62));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 62));
        c.setAlignmentX(LEFT_ALIGNMENT);
        return c;
    }

    private static class NavItem extends JComponent {

        private final String text;
        private final Icons.Type icon;
        private boolean selected;
        private boolean hover;

        NavItem(String text, Icons.Type icon, Runnable action) {
            this.text = text;
            this.icon = icon;
            setPreferredSize(new Dimension(218, 46));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
            setAlignmentX(LEFT_ALIGNMENT);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hover = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover = false;
                    repaint();
                }

                @Override
                public void mouseClicked(MouseEvent e) {
                    action.run();
                }
            });
        }

        void setSelected(boolean selected) {
            this.selected = selected;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            if (selected) {
                g2.setColor(AuthComponents.PRIMARY);
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 12, 12));
            } else if (hover) {
                g2.setColor(new Color(255, 255, 255, 18));
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 12, 12));
            }
            Color fg = selected ? Color.WHITE : hover ? new Color(226, 234, 248) : new Color(176, 196, 228);
            Icons.paint(g2, icon, 16, (getHeight() - 20) / 2.0, 20, fg);
            g2.setFont(UI.font(selected ? Font.BOLD : Font.PLAIN, 15));
            g2.setColor(fg);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(text, 50, (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }
    }
}
