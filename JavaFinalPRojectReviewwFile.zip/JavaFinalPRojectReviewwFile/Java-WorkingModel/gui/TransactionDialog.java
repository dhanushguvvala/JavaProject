package gui;

import model.Categories;
import model.Transaction;
import service.FinancialAnalysisService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.basic.BasicSpinnerUI;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.time.LocalDate;
import java.util.Arrays;

public class TransactionDialog extends JDialog {

    public record Result(String type, double amount, String description, String category, LocalDate date) {
    }

    private Result result;
    private String type;
    private boolean userPickedCategory;
    private boolean programmatic;

    private final AuthComponents.HintTextField amountField = new AuthComponents.HintTextField("0.00");
    private final AuthComponents.HintTextField descriptionField = new AuthComponents.HintTextField("What was it for?");
    private final JComboBox<String> categoryBox = new JComboBox<>();
    private final JLabel suggestion = UI.label(" ", Font.PLAIN, 12, UI.PURPLE);
    private final Segmented segmented;
    private final JSpinner dateSpinner;

    private TransactionDialog(Window owner, Transaction existing) {
        super(owner, existing == null ? "Add Transaction" : "Edit Transaction", ModalityType.APPLICATION_MODAL);
        type = existing == null ? "Expense" : existing.getType();
        userPickedCategory = existing != null;

        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(Color.WHITE);
        root.setBorder(new EmptyBorder(26, 30, 26, 30));

        segmented = new Segmented(new String[]{"Expense", "Income"}, "Income".equalsIgnoreCase(type) ? 1 : 0, i -> {
            type = i == 0 ? "Expense" : "Income";
            reloadCategories(null);
        });

        UI.styleCombo(categoryBox);
        categoryBox.addActionListener(e -> {
            if (!programmatic) {
                userPickedCategory = true;
                suggestion.setText(" ");
            }
        });

        dateSpinner = DateSpinnerUtil.createDateSpinner(existing == null ? LocalDate.now() : existing.getDate());
        styleSpinner(dateSpinner);

        reloadCategories(existing == null ? null : existing.getCategory());

        if (existing != null) {
            amountField.setText(plain(existing.getAmount()));
            descriptionField.setText(existing.getDescription());
        }

        descriptionField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                suggest();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                suggest();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                suggest();
            }
        });

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;

        add(root, UI.label(existing == null ? "Add transaction" : "Edit transaction", Font.BOLD, 24, UI.TEXT), c, 0);
        add(root, UI.label("Record money coming in or going out", Font.PLAIN, 14, UI.MUTED), c, 4);
        add(root, segmented, c, 20);
        add(root, fieldLabel("Amount"), c, 18);
        add(root, new UI.InputField(amountField, null, "\u20B9"), c, 8);
        add(root, fieldLabel("Description"), c, 16);
        add(root, new UI.InputField(descriptionField, Icons.Type.RECEIPT, null), c, 8);
        add(root, suggestion, c, 6);

        JPanel row = new JPanel(new GridLayout(1, 2, 14, 0));
        row.setOpaque(false);
        row.add(column("Category", categoryBox));
        row.add(column("Date", dateSpinner));
        add(root, row, c, 10);

        UI.AppButton cancel = new UI.AppButton("Cancel", null, UI.Variant.SECONDARY);
        UI.AppButton save = new UI.AppButton(existing == null ? "Save transaction" : "Save changes", Icons.Type.CHECK, UI.Variant.PRIMARY);
        cancel.setPreferredSize(new Dimension(120, 46));
        save.setPreferredSize(new Dimension(200, 46));
        cancel.addActionListener(e -> dispose());
        save.addActionListener(e -> save());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        buttons.setOpaque(false);
        buttons.add(cancel);
        buttons.add(save);
        add(root, buttons, c, 26);

        setContentPane(root);
        getRootPane().setDefaultButton(save);
        getRootPane().registerKeyboardAction(e -> dispose(),
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        pack();
        setSize(Math.max(getWidth(), 520), getHeight());
        setLocationRelativeTo(owner);
        SwingUtilities.invokeLater(amountField::requestFocusInWindow);
        setVisible(true);
    }

    public static Result open(Component parent, Transaction existing) {
        Window owner = parent instanceof Window w ? w : SwingUtilities.getWindowAncestor(parent);
        return new TransactionDialog(owner, existing).result;
    }

    private static void add(JPanel root, JComponent comp, GridBagConstraints c, int top) {
        c.insets = new Insets(top, 0, 0, 0);
        root.add(comp, c);
        c.gridy++;
    }

    private static JLabel fieldLabel(String text) {
        return UI.label(text, Font.BOLD, 14, UI.TEXT);
    }

    private static JPanel column(String label, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setOpaque(false);
        p.add(fieldLabel(label), BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    private void reloadCategories(String select) {
        programmatic = true;
        categoryBox.setModel(new DefaultComboBoxModel<>(Categories.forType(type)));
        if (select != null) {
            if (Arrays.asList(Categories.forType(type)).contains(select)) {
                categoryBox.setSelectedItem(select);
            } else {
                categoryBox.addItem(select);
                categoryBox.setSelectedItem(select);
            }
        }
        programmatic = false;
        if (select == null) {
            userPickedCategory = false;
            suggest();
        }
    }

    private void suggest() {
        if (userPickedCategory) {
            return;
        }
        String s = FinancialAnalysisService.suggestCategory(descriptionField.getText());
        if (s != null && "Expense".equals(type) && Arrays.asList(Categories.EXPENSE).contains(s)) {
            programmatic = true;
            categoryBox.setSelectedItem(s);
            programmatic = false;
            suggestion.setText("Smart category: auto-selected " + s + " from the description");
        } else {
            suggestion.setText(" ");
        }
    }

    private void save() {
        double amount;
        try {
            amount = Double.parseDouble(amountField.getText().trim().replace(",", ""));
        } catch (NumberFormatException e) {
            MessageDialog.show(this, "Invalid Amount", "Enter a valid amount, for example 1500 or 249.50.", MessageDialog.Type.WARNING);
            amountField.requestFocusInWindow();
            return;
        }
        if (amount <= 0 || Double.isNaN(amount) || Double.isInfinite(amount)) {
            MessageDialog.show(this, "Invalid Amount", "Amount must be greater than zero.", MessageDialog.Type.WARNING);
            amountField.requestFocusInWindow();
            return;
        }
        String description = descriptionField.getText().trim();
        if (description.isEmpty()) {
            MessageDialog.show(this, "Description Required", "Add a short description so you can recognise this later.", MessageDialog.Type.INFO);
            descriptionField.requestFocusInWindow();
            return;
        }
        try {
            dateSpinner.commitEdit();
        } catch (java.text.ParseException ignored) {
        }
        result = new Result(type, Math.round(amount * 100) / 100.0, description,
                (String) categoryBox.getSelectedItem(), DateSpinnerUtil.getSelectedDate(dateSpinner));
        dispose();
    }

    private static String plain(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.format(java.util.Locale.ENGLISH, "%.2f", v);
    }

    private static void styleSpinner(JSpinner spinner) {
        spinner.setUI(new BasicSpinnerUI() {
            @Override
            protected Component createNextButton() {
                return arrow(true);
            }

            @Override
            protected Component createPreviousButton() {
                return arrow(false);
            }

            private Component arrow(boolean next) {
                JButton b = new JButton() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        Graphics2D g2 = AuthComponents.smooth(g);
                        if (getModel().isRollover()) {
                            g2.setColor(new Color(241, 245, 249));
                            g2.fill(new RoundRectangle2D.Double(2, 2, getWidth() - 4, getHeight() - 4, 8, 8));
                        }
                        Icons.paint(g2, next ? Icons.Type.ARROW_UP : Icons.Type.ARROW_DOWN, (getWidth() - 12) / 2.0, (getHeight() - 12) / 2.0, 12, UI.MUTED);
                        g2.dispose();
                    }
                };
                b.setContentAreaFilled(false);
                b.setBorderPainted(false);
                b.setFocusPainted(false);
                b.setRolloverEnabled(true);
                b.setPreferredSize(new Dimension(26, 18));
                if (next) {
                    installNextButtonListeners(b);
                } else {
                    installPreviousButtonListeners(b);
                }
                return b;
            }
        });
        spinner.setBorder(new UI.RoundBorder(new Insets(2, 8, 2, 4)));
        spinner.setOpaque(false);
        spinner.setBackground(Color.WHITE);
        spinner.setPreferredSize(new Dimension(150, 42));
        JComponent editor = spinner.getEditor();
        editor.setOpaque(false);
        JFormattedTextField tf = ((JSpinner.DefaultEditor) editor).getTextField();
        tf.setBorder(null);
        tf.setOpaque(false);
        tf.setFont(UI.font(Font.PLAIN, 15));
        tf.setForeground(UI.TEXT);
        tf.setHorizontalAlignment(SwingConstants.LEFT);
        tf.setCaretColor(UI.PRIMARY);
    }

    static class Segmented extends JComponent {

        private final String[] options;
        private int selected;

        Segmented(String[] options, int selected, java.util.function.IntConsumer onChange) {
            this.options = options;
            this.selected = selected;
            setPreferredSize(new Dimension(300, 44));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    int i = Math.min(options.length - 1, e.getX() * options.length / Math.max(1, getWidth()));
                    if (i != Segmented.this.selected) {
                        Segmented.this.selected = i;
                        repaint();
                        onChange.accept(i);
                    }
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            g2.setColor(new Color(241, 245, 249));
            g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 12, 12));
            double w = getWidth() / (double) options.length;
            g2.setFont(UI.font(Font.BOLD, 14));
            FontMetrics fm = g2.getFontMetrics();
            for (int i = 0; i < options.length; i++) {
                boolean sel = i == selected;
                Color accent = options[i].equals("Income") ? UI.SUCCESS : UI.DANGER;
                if (sel) {
                    g2.setColor(Color.WHITE);
                    g2.fill(new RoundRectangle2D.Double(i * w + 4, 4, w - 8, getHeight() - 8, 9, 9));
                    g2.setColor(UI.BORDER);
                    g2.draw(new RoundRectangle2D.Double(i * w + 4, 4, w - 8, getHeight() - 8, 9, 9));
                }
                Icons.Type icon = options[i].equals("Income") ? Icons.Type.TREND_UP : Icons.Type.TREND_DOWN;
                int tw = fm.stringWidth(options[i]) + 26;
                double x = i * w + (w - tw) / 2;
                Color fg = sel ? accent : UI.MUTED;
                Icons.paint(g2, icon, x, (getHeight() - 18) / 2.0, 18, fg);
                g2.setColor(sel ? UI.TEXT : UI.MUTED);
                g2.drawString(options[i], (float) (x + 26), (getHeight() - fm.getHeight()) / 2f + fm.getAscent());
            }
            g2.dispose();
        }
    }
}
