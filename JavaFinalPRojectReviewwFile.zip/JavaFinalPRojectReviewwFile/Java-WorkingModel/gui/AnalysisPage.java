package gui;

import service.FinancialAnalysisService.Factor;
import service.FinancialAnalysisService.Insight;
import service.FinancialAnalysisService.Kind;
import service.FinancialAnalysisService.Report;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class AnalysisPage extends Page {

    private final Charts.ScoreGauge gauge = new Charts.ScoreGauge();
    private final JTextArea summary = UI.wrap(" ", 14, UI.MUTED);
    private final JLabel scoreTitle = UI.label(" ", Font.BOLD, 17, UI.TEXT);
    private final JPanel factors = stack();
    private final JPanel good = stack();
    private final JPanel attention = stack();
    private final JPanel tips = stack();
    private final JPanel forecast = stack();

    public AnalysisPage(AppContext ctx) {
        super(ctx);

        UI.Card scoreCard = new UI.Card(new BorderLayout(0, 6));
        JPanel sh = new JPanel(new GridLayout(2, 1, 0, 2));
        sh.setOpaque(false);
        sh.add(scoreTitle);
        sh.add(UI.label("Calculated from this month's transactions and budgets", Font.PLAIN, 13, UI.MUTED));
        scoreCard.add(sh, BorderLayout.NORTH);
        gauge.setPreferredSize(new Dimension(260, 230));
        scoreCard.add(gauge, BorderLayout.CENTER);
        summary.setBorder(new EmptyBorder(4, 6, 0, 6));
        scoreCard.add(summary, BorderLayout.SOUTH);

        UI.Card factorCard = new UI.Card(new BorderLayout());
        factorCard.add(UI.cardHeader("Score breakdown", "Five factors that make up your score", null), BorderLayout.NORTH);
        factorCard.add(top(factors), BorderLayout.CENTER);
        addRow(row(new double[]{0.4, 0.6}, scoreCard, factorCard), 0);

        addRow(equalRow(
                insightCard("What's going well", "Habits worth keeping", good),
                insightCard("Needs attention", "Issues that are costing you", attention)), 0);
        addRow(equalRow(
                insightCard("Recommendations", "Specific next steps", tips),
                insightCard("Forecast and highlights", "Projections from your recent months", forecast)), 1);
    }

    private static UI.Card insightCard(String title, String sub, JPanel body) {
        UI.Card card = new UI.Card(new BorderLayout());
        card.add(UI.cardHeader(title, sub, null), BorderLayout.NORTH);
        card.add(top(body), BorderLayout.CENTER);
        return card;
    }

    @Override
    public String title() {
        return "AI analysis";
    }

    @Override
    public String subtitle() {
        return "Financial score and personalised insights for " + AppContext.MONTH.format(ctx.getMonth());
    }

    @Override
    public void refresh() {
        Report r = ctx.analysis.analyze(ctx.getMonth());
        scoreTitle.setText("Financial score for " + AppContext.MONTH.format(r.month()));
        gauge.set(r.score(), r.grade(), r.hasData());
        summary.setText(r.summary());

        factors.removeAll();
        if (!r.hasData()) {
            factors.add(UI.emptyState(Icons.Type.CHART, "No data for this month", "Pick another month or add transactions."));
        }
        for (Factor f : r.factors()) {
            factors.add(factorRow(f));
        }

        fill(good, r.of(Kind.POSITIVE), "Nothing to highlight yet for this month.");
        fill(attention, r.of(Kind.WARNING), "No problems detected this month.");
        fill(tips, r.of(Kind.TIP), "No recommendations right now.");
        fill(forecast, r.of(Kind.FORECAST), "Add more transactions to unlock projections.");
        revalidate();
        repaint();
    }

    private static JPanel factorRow(Factor f) {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(8, 0, 12, 0));
        JPanel top = new JPanel(new BorderLayout(12, 0));
        top.setOpaque(false);
        JPanel texts = new JPanel(new GridLayout(2, 1, 0, 1));
        texts.setOpaque(false);
        texts.add(UI.label(f.name(), Font.BOLD, 14, UI.TEXT));
        texts.add(UI.label(f.note(), Font.PLAIN, 12, UI.MUTED));
        top.add(texts, BorderLayout.CENTER);
        JLabel pts = UI.label(f.score() + " / " + f.max(), Font.BOLD, 15, UI.TEXT);
        top.add(pts, BorderLayout.EAST);
        double ratio = f.score() / (double) f.max();
        UI.Progress bar = new UI.Progress();
        bar.set(ratio, UI.scoreColor((int) Math.round(ratio * 100)));
        p.add(top, BorderLayout.NORTH);
        p.add(bar, BorderLayout.CENTER);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, p.getPreferredSize().height));
        p.setAlignmentX(LEFT_ALIGNMENT);
        return p;
    }

    private static void fill(JPanel panel, List<Insight> items, String empty) {
        panel.removeAll();
        if (items.isEmpty()) {
            JLabel l = UI.label(empty, Font.PLAIN, 14, UI.MUTED);
            l.setAlignmentX(LEFT_ALIGNMENT);
            panel.add(l);
            return;
        }
        for (Insight i : items) {
            panel.add(insightRow(i));
        }
    }

    private static JPanel insightRow(Insight i) {
        Icons.Type icon;
        Color color;
        switch (i.kind()) {
            case POSITIVE -> {
                icon = Icons.Type.CHECK;
                color = UI.SUCCESS;
            }
            case WARNING -> {
                icon = Icons.Type.ALERT;
                color = UI.DANGER;
            }
            case TIP -> {
                icon = Icons.Type.BULB;
                color = UI.WARNING;
            }
            default -> {
                icon = Icons.Type.TREND_UP;
                color = UI.PRIMARY;
            }
        }
        JPanel p = new JPanel(new BorderLayout(14, 0));
        p.setOpaque(false);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(241, 245, 249)), new EmptyBorder(10, 0, 12, 0)));
        JPanel badge = new JPanel(new BorderLayout());
        badge.setOpaque(false);
        badge.add(new UI.IconBadge(icon, color, 36), BorderLayout.NORTH);
        p.add(badge, BorderLayout.WEST);
        JPanel texts = new JPanel(new BorderLayout(0, 3));
        texts.setOpaque(false);
        texts.add(UI.label(i.title(), Font.BOLD, 14, UI.TEXT), BorderLayout.NORTH);
        texts.add(UI.wrap(i.detail(), 13, UI.MUTED), BorderLayout.CENTER);
        p.add(texts, BorderLayout.CENTER);
        p.setAlignmentX(LEFT_ALIGNMENT);
        return p;
    }
}
