package gui;

import model.Categories;
import service.BudgetService;
import util.Money;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class BudgetsPage extends Page {

    private final UI.StatCard total = new UI.StatCard("TOTAL BUDGET", Icons.Type.TARGET, UI.PRIMARY);
    private final UI.StatCard used = new UI.StatCard("SPENT IN BUDGETS", Icons.Type.TREND_DOWN, UI.WARNING);
    private final UI.StatCard left = new UI.StatCard("REMAINING", Icons.Type.WALLET, UI.SUCCESS);
    private final UI.StatCard over = new UI.StatCard("OVER LIMIT", Icons.Type.ALERT, UI.DANGER);
    private final Map<String, AuthComponents.HintTextField> inputs = new LinkedHashMap<>();
    private final Map<String, UI.Progress> bars = new LinkedHashMap<>();
    private final Map<String, JLabel> spentLabels = new LinkedHashMap<>();
    private final Map<String, StatusPill> pills = new LinkedHashMap<>();

    public BudgetsPage(AppContext ctx) {
        super(ctx);
        addRow(equalRow(total, used, left, over), 0);

        UI.AppButton save = new UI.AppButton("Save budgets", Icons.Type.SAVE, UI.Variant.PRIMARY);
        save.addActionListener(e -> save());
        UI.Card card = new UI.Card(new BorderLayout());
        card.add(UI.cardHeader("Monthly limits", "Set a limit for each category. Leave a field empty for no limit.", save), BorderLayout.NORTH);

        JPanel list = stack();
        list.add(headerRow());
        for (String cat : Categories.EXPENSE) {
            list.add(budgetRow(cat));
        }
        card.add(top(list), BorderLayout.CENTER);
        addRow(card, 1);
    }

    private static final int[] WIDTHS = {200, 0, 170, 130, 170};

    private JPanel headerRow() {
        JPanel r = grid();
        r.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UI.BORDER), new EmptyBorder(4, 0, 8, 0)));
        String[] heads = {"CATEGORY", "PROGRESS", "SPENT", "STATUS", "MONTHLY LIMIT"};
        for (int i = 0; i < heads.length; i++) {
            JLabel l = UI.label(heads[i], Font.BOLD, 12, UI.MUTED);
            if (i == 2) {
                l.setHorizontalAlignment(SwingConstants.RIGHT);
            }
            if (WIDTHS[i] > 0) {
                l.setPreferredSize(new Dimension(WIDTHS[i], 20));
            }
            r.add(l, cell(i));
        }
        r.setAlignmentX(LEFT_ALIGNMENT);
        r.setMaximumSize(new Dimension(Integer.MAX_VALUE, r.getPreferredSize().height));
        return r;
    }

    private JPanel budgetRow(String cat) {
        JPanel r = grid();
        r.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(241, 245, 249)), new EmptyBorder(10, 0, 10, 0)));
        JPanel name = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        name.setOpaque(false);
        name.add(new UI.IconBadge(Icons.Type.TARGET, UI.categoryColor(cat), 32));
        name.add(UI.label(cat, Font.BOLD, 14, UI.TEXT));
        name.setPreferredSize(new Dimension(WIDTHS[0], 36));
        r.add(name, cell(0));

        UI.Progress bar = new UI.Progress();
        bars.put(cat, bar);
        r.add(bar, cell(1));

        JLabel spent = UI.label(" ", Font.PLAIN, 14, UI.TEXT);
        spent.setHorizontalAlignment(SwingConstants.RIGHT);
        spent.setPreferredSize(new Dimension(WIDTHS[2], 20));
        spentLabels.put(cat, spent);
        r.add(spent, cell(2));

        StatusPill pill = new StatusPill();
        pills.put(cat, pill);
        r.add(pill, cell(3));

        AuthComponents.HintTextField field = new AuthComponents.HintTextField("No limit");
        inputs.put(cat, field);
        UI.InputField input = new UI.InputField(field, null, "\u20B9");
        input.setPreferredSize(new Dimension(WIDTHS[4], 40));
        r.add(input, cell(4));
        r.setAlignmentX(LEFT_ALIGNMENT);
        r.setMaximumSize(new Dimension(Integer.MAX_VALUE, r.getPreferredSize().height));
        return r;
    }

    private static JPanel grid() {
        JPanel r = new JPanel(new GridBagLayout());
        r.setOpaque(false);
        return r;
    }

    private static GridBagConstraints cell(int i) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = i;
        g.gridy = 0;
        g.anchor = GridBagConstraints.WEST;
        g.fill = i == 1 ? GridBagConstraints.HORIZONTAL : GridBagConstraints.NONE;
        g.weightx = i == 1 ? 1 : 0;
        g.insets = new Insets(0, i == 0 ? 0 : 18, 0, 0);
        return g;
    }

    @Override
    public String title() {
        return "Budgets";
    }

    @Override
    public String subtitle() {
        return "Monthly spending limits, tracked for " + AppContext.MONTH.format(ctx.getMonth());
    }

    @Override
    public void refresh() {
        Map<String, Double> spent = ctx.transactions.getExpenseByCategory(ctx.getMonth());
        Map<String, Double> limits = ctx.budgets.getLimits();
        double totalLimit = 0;
        double totalUsed = 0;
        int overCount = 0;
        for (String cat : Categories.EXPENSE) {
            double s = spent.getOrDefault(cat, 0.0);
            double l = limits.getOrDefault(cat, 0.0);
            inputs.get(cat).setText(l > 0 ? plain(l) : "");
            BudgetService.Status st = BudgetService.status(s, l);
            Color c = switch (st) {
                case OVER -> UI.DANGER;
                case NEAR_LIMIT -> UI.WARNING;
                case ON_TRACK -> UI.SUCCESS;
                default -> UI.FAINT;
            };
            bars.get(cat).set(l > 0 ? s / l : 0, c);
            spentLabels.get(cat).setText(l > 0 ? Money.format(s) + " / " + Money.compact(l) : Money.format(s));
            spentLabels.get(cat).setForeground(st == BudgetService.Status.OVER ? UI.DANGER : UI.TEXT);
            pills.get(cat).set(st, s, l);
            if (l > 0) {
                totalLimit += l;
                totalUsed += s;
                if (s > l) {
                    overCount++;
                }
            }
        }
        total.set(Money.format(totalLimit), UI.TEXT, limits.size() + (limits.size() == 1 ? " category" : " categories") + " budgeted", UI.MUTED);
        used.set(Money.format(totalUsed), UI.TEXT, totalLimit > 0 ? String.format("%.0f%% of total budget", totalUsed / totalLimit * 100) : "No budgets yet", UI.MUTED);
        double rem = totalLimit - totalUsed;
        left.set(Money.format(rem), rem < 0 ? UI.DANGER : UI.TEXT, rem < 0 ? "Over total budget" : "Left to spend this month", rem < 0 ? UI.DANGER : UI.MUTED);
        over.set(String.valueOf(overCount), overCount > 0 ? UI.DANGER : UI.TEXT, overCount == 0 ? "All within limits" : "Needs attention", overCount > 0 ? UI.DANGER : UI.MUTED);
        revalidate();
        repaint();
    }

    private void save() {
        Map<String, Double> map = new LinkedHashMap<>();
        for (Map.Entry<String, AuthComponents.HintTextField> e : inputs.entrySet()) {
            String text = e.getValue().getText().trim().replace(",", "");
            if (text.isEmpty()) {
                continue;
            }
            try {
                double v = Double.parseDouble(text);
                if (v < 0) {
                    throw new NumberFormatException();
                }
                if (v > 0) {
                    map.put(e.getKey(), v);
                }
            } catch (NumberFormatException ex) {
                MessageDialog.show(this, "Invalid Limit", "Enter a valid amount for " + e.getKey() + ", or leave it empty.", MessageDialog.Type.WARNING);
                e.getValue().requestFocusInWindow();
                return;
            }
        }
        ctx.budgets.setLimits(map);
        ctx.fire();
        MessageDialog.show(this, "Budgets Saved", map.isEmpty() ? "All budget limits were cleared."
                : "Limits saved for " + map.size() + (map.size() == 1 ? " category." : " categories.") + " You'll be alerted when spending gets close.", MessageDialog.Type.SUCCESS);
    }

    private static String plain(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.format(Locale.ENGLISH, "%.2f", v);
    }

    private static class StatusPill extends JComponent {

        private String text = "";
        private Color color = UI.FAINT;

        StatusPill() {
            setPreferredSize(new Dimension(WIDTHS[3], 28));
        }

        void set(BudgetService.Status st, double spent, double limit) {
            switch (st) {
                case OVER -> {
                    text = "Over by " + Money.compact(spent - limit);
                    color = UI.DANGER;
                }
                case NEAR_LIMIT -> {
                    text = "Near limit";
                    color = UI.WARNING;
                }
                case ON_TRACK -> {
                    text = "On track";
                    color = UI.SUCCESS;
                }
                default -> {
                    text = "No limit";
                    color = UI.FAINT;
                }
            }
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            UI.paintPill(g2, text, 0, getHeight() / 2, UI.mix(color, Color.BLACK, 0.1), UI.soft(color), UI.font(Font.BOLD, 12));
            g2.dispose();
        }
    }
}
