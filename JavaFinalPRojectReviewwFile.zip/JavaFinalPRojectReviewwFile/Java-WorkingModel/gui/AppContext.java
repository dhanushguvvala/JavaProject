package gui;

import model.Transaction;
import service.BudgetService;
import service.FinancialAnalysisService;
import service.TransactionService;
import util.Money;

import java.awt.Component;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

public class AppContext {

    public static final DateTimeFormatter MONTH = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH);
    public static final DateTimeFormatter MONTH_SHORT = DateTimeFormatter.ofPattern("MMM", Locale.ENGLISH);
    public static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH);

    public final String username;
    public final TransactionService transactions;
    public final BudgetService budgets;
    public final FinancialAnalysisService analysis;

    private YearMonth month;
    private final List<Runnable> listeners = new ArrayList<>();
    private Consumer<String> navigator = page -> { };

    public AppContext(String username) {
        this.username = username;
        this.transactions = new TransactionService(username);
        this.budgets = new BudgetService(username);
        this.analysis = new FinancialAnalysisService(transactions, budgets);
        this.month = transactions.getLatestMonth();
    }

    public YearMonth getMonth() {
        return month;
    }

    public void setMonth(YearMonth month) {
        if (month != null && !month.equals(this.month)) {
            this.month = month;
            fire();
        }
    }

    public void onChange(Runnable listener) {
        listeners.add(listener);
    }

    public void fire() {
        for (Runnable r : listeners) {
            r.run();
        }
    }

    public void setNavigator(Consumer<String> navigator) {
        this.navigator = navigator;
    }

    public void navigate(String page) {
        navigator.accept(page);
    }

    public void addTransaction(Component parent) {
        TransactionDialog.Result r = TransactionDialog.open(parent, null);
        if (r == null) {
            return;
        }
        Transaction t = transactions.add(r.type(), r.amount(), r.description(), r.category(), r.date());
        month = t.getMonth();
        fire();
        budgetAlert(parent, t);
    }

    public void editTransaction(Component parent, int id) {
        Transaction existing = transactions.find(id);
        if (existing == null) {
            return;
        }
        TransactionDialog.Result r = TransactionDialog.open(parent, existing);
        if (r == null) {
            return;
        }
        transactions.update(id, r.type(), r.amount(), r.description(), r.category(), r.date());
        fire();
        budgetAlert(parent, existing);
    }

    public void deleteTransaction(Component parent, int id) {
        Transaction t = transactions.find(id);
        if (t == null) {
            return;
        }
        boolean ok = MessageDialog.confirm(parent, "Delete Transaction",
                "Delete \"" + t.getDescription() + "\" (" + Money.format(t.getAmount()) + ")? This can't be undone.",
                MessageDialog.Type.WARNING, "Delete");
        if (ok) {
            transactions.delete(id);
            fire();
        }
    }

    private void budgetAlert(Component parent, Transaction t) {
        if (!t.isExpense()) {
            return;
        }
        double limit = budgets.getLimit(t.getCategory());
        if (limit <= 0) {
            return;
        }
        double spent = transactions.getExpenseByCategory(t.getMonth()).getOrDefault(t.getCategory(), 0.0);
        String monthName = MONTH.format(t.getMonth());
        switch (BudgetService.status(spent, limit)) {
            case OVER -> MessageDialog.show(parent, "Budget Exceeded",
                    t.getCategory() + " budget for " + monthName + " is exceeded by " + Money.format(spent - limit)
                            + ".\nSpent " + Money.format(spent) + " of " + Money.format(limit) + ".",
                    MessageDialog.Type.WARNING);
            case NEAR_LIMIT -> MessageDialog.show(parent, "Budget Alert",
                    String.format("You've used %.0f%% of your %s budget for %s.", spent / limit * 100, t.getCategory(), monthName),
                    MessageDialog.Type.INFO);
            default -> {
            }
        }
    }
}
