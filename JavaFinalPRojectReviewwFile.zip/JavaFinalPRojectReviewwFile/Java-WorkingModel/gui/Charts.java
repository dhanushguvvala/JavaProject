package gui;

import util.Money;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.IntConsumer;

public final class Charts {

    private Charts() {
    }

    private static double niceMax(double v) {
        if (v <= 0) {
            return 1000;
        }
        double exp = Math.pow(10, Math.floor(Math.log10(v)));
        double f = v / exp;
        double nice = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 4 ? 4 : f <= 5 ? 5 : f <= 6 ? 6 : f <= 8 ? 8 : 10;
        return nice * exp;
    }

    public static class BarChart extends JComponent {

        private final String[] names;
        private final Color[] colors;
        private String[] labels = {};
        private String[] tips = {};
        private double[][] values = {};
        private int selected = -1;
        private int hover = -1;
        private int labelEvery = 1;
        private IntConsumer onClick;

        public BarChart(String[] names, Color[] colors) {
            this.names = names;
            this.colors = colors;
            setPreferredSize(new Dimension(400, 260));
            setToolTipText("");
            MouseAdapter m = new MouseAdapter() {
                @Override
                public void mouseMoved(MouseEvent e) {
                    int h = groupAt(e.getX());
                    if (h != hover) {
                        hover = h;
                        setCursor(Cursor.getPredefinedCursor(onClick != null && h >= 0 ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
                        repaint();
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover = -1;
                    repaint();
                }

                @Override
                public void mouseClicked(MouseEvent e) {
                    int g = groupAt(e.getX());
                    if (g >= 0 && onClick != null) {
                        onClick.accept(g);
                    }
                }
            };
            addMouseListener(m);
            addMouseMotionListener(m);
        }

        public void setOnClick(IntConsumer onClick) {
            this.onClick = onClick;
        }

        public void setData(String[] labels, String[] tips, double[][] values, int selected, int labelEvery) {
            this.labels = labels;
            this.tips = tips;
            this.values = values;
            this.selected = selected;
            this.labelEvery = Math.max(1, labelEvery);
            repaint();
        }

        private Rectangle plot() {
            return new Rectangle(58, names.length > 1 ? 34 : 14, getWidth() - 68, getHeight() - (names.length > 1 ? 34 : 14) - 30);
        }

        private int groupAt(int x) {
            Rectangle p = plot();
            if (labels.length == 0 || x < p.x || x > p.x + p.width) {
                return -1;
            }
            int g = (int) ((x - p.x) / (p.width / (double) labels.length));
            return g >= 0 && g < labels.length ? g : -1;
        }

        @Override
        public String getToolTipText(MouseEvent e) {
            int g = groupAt(e.getX());
            if (g < 0) {
                return null;
            }
            StringBuilder sb = new StringBuilder("<html><b>").append(tips[g]).append("</b>");
            for (int s = 0; s < names.length; s++) {
                sb.append("<br>").append(names[s]).append(": ").append(Money.format(values[g][s]));
            }
            return sb.append("</html>").toString();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            Rectangle p = plot();
            double max = 0;
            for (double[] grp : values) {
                for (double v : grp) {
                    max = Math.max(max, v);
                }
            }
            max = niceMax(max * 1.05);

            g2.setFont(UI.font(Font.PLAIN, 12));
            FontMetrics fm = g2.getFontMetrics();
            for (int i = 0; i <= 4; i++) {
                int y = p.y + p.height - (int) (p.height * i / 4.0);
                g2.setColor(i == 0 ? UI.BORDER : new Color(241, 245, 249));
                g2.drawLine(p.x, y, p.x + p.width, y);
                g2.setColor(UI.FAINT);
                String t = Money.compact(max * i / 4.0);
                g2.drawString(t, p.x - 10 - fm.stringWidth(t), y + fm.getAscent() / 2 - 1);
            }

            if (names.length > 1) {
                int lx = p.x + p.width;
                for (int s = names.length - 1; s >= 0; s--) {
                    lx -= fm.stringWidth(names[s]);
                    g2.setColor(UI.MUTED);
                    g2.drawString(names[s], lx, 16);
                    lx -= 16;
                    g2.setColor(colors[s]);
                    g2.fill(new RoundRectangle2D.Double(lx, 7, 10, 10, 3, 3));
                    lx -= 18;
                }
            }

            int n = labels.length;
            if (n == 0) {
                g2.dispose();
                return;
            }
            double gw = p.width / (double) n;
            int series = names.length;
            double bw = Math.min(26, (gw * 0.72 - (series - 1) * 4) / series);
            double groupBars = bw * series + (series - 1) * 4;

            for (int i = 0; i < n; i++) {
                double gx = p.x + gw * i;
                if (i == selected || i == hover) {
                    g2.setColor(i == selected ? new Color(232, 241, 255, 180) : new Color(241, 245, 249));
                    g2.fill(new RoundRectangle2D.Double(gx + 2, p.y, gw - 4, p.height, 10, 10));
                }
                double bx = gx + (gw - groupBars) / 2;
                for (int s = 0; s < series; s++) {
                    double v = values[i][s];
                    double h = v <= 0 ? 0 : Math.max(3, p.height * v / max);
                    double y = p.y + p.height - h;
                    g2.setColor(colors[s]);
                    if (h > 0) {
                        double r = Math.min(8, bw);
                        g2.fill(new RoundRectangle2D.Double(bx, y, bw, h, r, r));
                        g2.fill(new Rectangle2D.Double(bx, y + Math.min(h / 2, r / 2), bw, h - Math.min(h / 2, r / 2)));
                    }
                    bx += bw + 4;
                }
                if (i % labelEvery == 0 || i == selected) {
                    g2.setFont(UI.font(i == selected ? Font.BOLD : Font.PLAIN, 12));
                    FontMetrics lf = g2.getFontMetrics();
                    g2.setColor(i == selected ? UI.PRIMARY : UI.MUTED);
                    g2.drawString(labels[i], (int) (gx + (gw - lf.stringWidth(labels[i])) / 2), p.y + p.height + 20);
                }
            }
            g2.dispose();
        }
    }

    public static class DonutChart extends JComponent {

        private Map<String, Double> data = new LinkedHashMap<>();
        private String centerLabel = "spent";

        public DonutChart() {
            setPreferredSize(new Dimension(360, 240));
        }

        public void setData(Map<String, Double> data, String centerLabel) {
            this.data = data;
            this.centerLabel = centerLabel;
            repaint();
        }

        private List<Map.Entry<String, Double>> items() {
            List<Map.Entry<String, Double>> list = new ArrayList<>(data.entrySet());
            if (list.size() <= 6) {
                return list;
            }
            double rest = 0;
            for (int i = 5; i < list.size(); i++) {
                rest += list.get(i).getValue();
            }
            List<Map.Entry<String, Double>> top = new ArrayList<>(list.subList(0, 5));
            top.add(Map.entry("Others", rest));
            return top;
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            double total = data.values().stream().mapToDouble(Double::doubleValue).sum();
            int d = Math.min(getHeight() - 10, Math.min(210, (int) (getWidth() * 0.46)));
            int cx = 6;
            int cy = (getHeight() - d) / 2;
            float stroke = Math.max(18, d * 0.16f);
            double inset = stroke / 2.0;

            if (total <= 0) {
                g2.setColor(new Color(237, 241, 247));
                g2.setStroke(new BasicStroke(stroke));
                g2.draw(new Ellipse2D.Double(cx + inset, cy + inset, d - stroke, d - stroke));
                g2.setFont(UI.font(Font.PLAIN, 14));
                g2.setColor(UI.MUTED);
                g2.drawString("No expenses this month", cx + d + 24, getHeight() / 2 + 5);
                g2.dispose();
                return;
            }

            List<Map.Entry<String, Double>> items = items();
            double start = 90;
            g2.setStroke(new BasicStroke(stroke, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND));
            for (Map.Entry<String, Double> e : items) {
                double extent = -360 * e.getValue() / total;
                g2.setColor(e.getKey().equals("Others") ? UI.FAINT : UI.categoryColor(e.getKey()));
                g2.draw(new Arc2D.Double(cx + inset, cy + inset, d - stroke, d - stroke, start, extent - (items.size() > 1 ? -1.2 : 0), Arc2D.OPEN));
                start += extent;
            }

            g2.setFont(UI.font(Font.BOLD, Math.max(15, d / 9)));
            FontMetrics fm = g2.getFontMetrics();
            String t = Money.compact(total);
            g2.setColor(UI.TEXT);
            g2.drawString(t, cx + (d - fm.stringWidth(t)) / 2, cy + d / 2 + 2);
            g2.setFont(UI.font(Font.PLAIN, 12));
            FontMetrics sm = g2.getFontMetrics();
            g2.setColor(UI.MUTED);
            g2.drawString(centerLabel, cx + (d - sm.stringWidth(centerLabel)) / 2, cy + d / 2 + 20);

            int lx = cx + d + 26;
            int rowH = 30;
            int ly = (getHeight() - items.size() * rowH) / 2 + 18;
            int right = getWidth() - 4;
            for (Map.Entry<String, Double> e : items) {
                Color c = e.getKey().equals("Others") ? UI.FAINT : UI.categoryColor(e.getKey());
                g2.setColor(c);
                g2.fill(new RoundRectangle2D.Double(lx, ly - 10, 10, 10, 4, 4));
                g2.setFont(UI.font(Font.PLAIN, 13));
                g2.setColor(UI.TEXT);
                g2.drawString(e.getKey(), lx + 18, ly);
                String pct = String.format("%.0f%%", e.getValue() / total * 100);
                g2.setFont(UI.font(Font.BOLD, 13));
                FontMetrics bf = g2.getFontMetrics();
                g2.drawString(pct, right - bf.stringWidth(pct), ly);
                String amt = Money.compact(e.getValue());
                g2.setFont(UI.font(Font.PLAIN, 13));
                FontMetrics pf = g2.getFontMetrics();
                g2.setColor(UI.MUTED);
                g2.drawString(amt, right - 48 - pf.stringWidth(amt), ly);
                ly += rowH;
            }
            g2.dispose();
        }
    }

    public static class ScoreGauge extends JComponent {

        private int score;
        private String grade = "";
        private boolean hasData;

        public ScoreGauge() {
            setPreferredSize(new Dimension(260, 200));
        }

        public void set(int score, String grade, boolean hasData) {
            this.score = score;
            this.grade = grade;
            this.hasData = hasData;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            int d = Math.min(getWidth() - 20, (int) ((getHeight() - 10) * 1.25));
            int x = (getWidth() - d) / 2;
            int y = 12;
            float stroke = 18;
            Arc2D.Double track = new Arc2D.Double(x + stroke / 2, y + stroke / 2, d - stroke, d - stroke, 210, -240, Arc2D.OPEN);
            g2.setStroke(new BasicStroke(stroke, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.setColor(new Color(237, 241, 247));
            g2.draw(track);
            Color c = hasData ? UI.scoreColor(score) : UI.FAINT;
            if (hasData && score > 0) {
                g2.setColor(c);
                g2.draw(new Arc2D.Double(track.x, track.y, track.width, track.height, 210, -240 * score / 100.0, Arc2D.OPEN));
            }
            int cx = getWidth() / 2;
            int cy = y + d / 2;
            g2.setFont(UI.font(Font.BOLD, 52));
            FontMetrics fm = g2.getFontMetrics();
            String s = hasData ? String.valueOf(score) : "--";
            g2.setColor(UI.TEXT);
            g2.drawString(s, cx - fm.stringWidth(s) / 2, cy + 14);
            g2.setFont(UI.font(Font.PLAIN, 14));
            FontMetrics sm = g2.getFontMetrics();
            g2.setColor(UI.MUTED);
            g2.drawString("out of 100", cx - sm.stringWidth("out of 100") / 2, cy + 38);
            Font pf = UI.font(Font.BOLD, 14);
            g2.setFont(pf);
            int pw = g2.getFontMetrics().stringWidth(grade) + 20;
            UI.paintPill(g2, grade, cx - pw / 2, cy + 70, c, UI.soft(c), pf);
            g2.dispose();
        }
    }
}
