package gui;

import model.Transaction;
import util.Money;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;

public class MonthlyReportPage extends Page {

    private final UI.StatCard spent = new UI.StatCard("TOTAL SPENT", Icons.Type.TREND_DOWN, UI.DANGER);
    private final UI.StatCard daily = new UI.StatCard("DAILY AVERAGE", Icons.Type.CLOCK, UI.PRIMARY);
    private final UI.StatCard count = new UI.StatCard("EXPENSE ENTRIES", Icons.Type.RECEIPT, UI.WARNING);
    private final UI.StatCard biggest = new UI.StatCard("BIGGEST EXPENSE", Icons.Type.ALERT, UI.PURPLE);
    private final Charts.BarChart dailyChart = new Charts.BarChart(new String[]{"Spent"}, new Color[]{new Color(59, 130, 246)});
    private final JPanel categories = stack();
    private final JPanel compare = stack();
    private final JPanel topList = stack();
    private final JLabel dailyTitle = UI.label(" ", Font.BOLD, 17, UI.TEXT);
    private final JLabel compareTitle = UI.label(" ", Font.BOLD, 17, UI.TEXT);

    public MonthlyReportPage(AppContext ctx) {
        super(ctx);
        addRow(equalRow(spent, daily, count, biggest), 0);

        UI.Card chartCard = new UI.Card(new BorderLayout());
        chartCard.add(header(dailyTitle, "Hover a bar to see the amount for that day"), BorderLayout.NORTH);
        dailyChart.setPreferredSize(new Dimension(300, 240));
        chartCard.add(dailyChart, BorderLayout.CENTER);
        addRow(chartCard, 0);

        UI.Card catCard = new UI.Card(new BorderLayout());
        catCard.add(UI.cardHeader("Category breakdown", "Share of spending and change from last month", null), BorderLayout.NORTH);
        catCard.add(top(categories), BorderLayout.CENTER);

        UI.Card compareCard = new UI.Card(new BorderLayout());
        compareCard.add(header(compareTitle, "This month against the month before"), BorderLayout.NORTH);
        compareCard.add(top(compare), BorderLayout.CENTER);
        addRow(row(new double[]{0.58, 0.42}, catCard, compareCard), 0);

        UI.Card topCard = new UI.Card(new BorderLayout());
        topCard.add(UI.cardHeader("Top expenses", "Your five largest payments this month", null), BorderLayout.NORTH);
        topCard.add(top(topList), BorderLayout.CENTER);
        addRow(topCard, 1);
    }

    private static JPanel header(JLabel title, String sub) {
        JPanel p = new JPanel(new GridLayout(2, 1, 0, 2));
        p.setOpaque(false);
        p.add(title);
        p.add(UI.label(sub, Font.PLAIN, 13, UI.MUTED));
        p.setBorder(new EmptyBorder(0, 0, 14, 0));
        return p;
    }

    @Override
    public String title() {
        return "Monthly report";
    }

    @Override
    public String subtitle() {
        return "Where your money went in " + AppContext.MONTH.format(ctx.getMonth());
    }

    @Override
    public void refresh() {
        YearMonth m = ctx.getMonth();
        YearMonth prev = m.minusMonths(1);
        String prevShort = AppContext.MONTH_SHORT.format(prev);
        double out = ctx.transactions.getExpense(m);
        double pout = ctx.transactions.getExpense(prev);
        int days = m.equals(YearMonth.now()) ? LocalDate.now().getDayOfMonth() : m.lengthOfMonth();
        int n = ctx.transactions.countExpenses(m);
        List<Transaction> topFive = ctx.transactions.getTopExpenses(m, 5);

        spent.set(Money.format(out), UI.TEXT, delta(out, pout, prevShort), deltaColor(out, pout, false));
        daily.set(Money.format(Math.round(out / days)), UI.TEXT, "Across " + days + " days", UI.MUTED);
        count.set(String.valueOf(n), UI.TEXT, n == 0 ? "No expenses" : "Avg " + Money.format(Math.round(out / n)) + " each", UI.MUTED);
        if (topFive.isEmpty()) {
            biggest.set("--", UI.FAINT, "No expenses", UI.MUTED);
        } else {
            Transaction t = topFive.get(0);
            biggest.set(Money.format(t.getAmount()), UI.TEXT, t.getDescription(), UI.MUTED);
        }

        dailyTitle.setText("Daily spending in " + AppContext.MONTH.format(m));
        double[] perDay = ctx.transactions.getDailyExpense(m);
        String[] labels = new String[perDay.length];
        String[] tips = new String[perDay.length];
        double[][] vals = new double[perDay.length][1];
        for (int i = 0; i < perDay.length; i++) {
            labels[i] = String.valueOf(i + 1);
            tips[i] = AppContext.DATE.format(m.atDay(i + 1));
            vals[i][0] = perDay[i];
        }
        dailyChart.setData(labels, tips, vals, -1, 3);

        buildCategories(m, prev, out);
        buildCompare(m, prev);

        topList.removeAll();
        if (topFive.isEmpty()) {
            topList.add(UI.emptyState(Icons.Type.RECEIPT, "No expenses this month", "Expenses you add will be ranked here."));
        } else {
            int rank = 1;
            for (Transaction t : topFive) {
                topList.add(new ListRow(new RankBadge(rank++), t.getDescription(),
                        t.getCategory() + "  \u2022  " + AppContext.DATE.format(t.getDate()),
                        Money.format(t.getAmount()), UI.TEXT));
            }
        }
        revalidate();
        repaint();
    }

    private void buildCategories(YearMonth m, YearMonth prev, double total) {
        categories.removeAll();
        Map<String, Double> cats = ctx.transactions.getExpenseByCategory(m);
        Map<String, Double> prevCats = ctx.transactions.getExpenseByCategory(prev);
        if (cats.isEmpty()) {
            categories.add(UI.emptyState(Icons.Type.CHART, "Nothing spent yet", "Category totals appear once you add expenses."));
            return;
        }
        for (Map.Entry<String, Double> e : cats.entrySet()) {
            JPanel r = new JPanel(new GridBagLayout());
            r.setOpaque(false);
            r.setBorder(new EmptyBorder(9, 0, 9, 0));
            Color c = UI.categoryColor(e.getKey());

            JPanel name = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            name.setOpaque(false);
            name.add(new UI.Dot(c));
            name.add(UI.label(e.getKey(), Font.BOLD, 14, UI.TEXT));
            name.setPreferredSize(new Dimension(140, 24));

            double share = e.getValue() / total;
            UI.Progress bar = new UI.Progress();
            bar.set(share, c);

            JLabel pct = UI.label(String.format("%.0f%%", share * 100), Font.BOLD, 13, UI.TEXT);
            pct.setHorizontalAlignment(SwingConstants.RIGHT);
            pct.setPreferredSize(new Dimension(46, 20));
            JLabel amt = UI.label(Money.format(e.getValue()), Font.PLAIN, 14, UI.TEXT);
            amt.setHorizontalAlignment(SwingConstants.RIGHT);
            amt.setPreferredSize(new Dimension(100, 20));

            double before = prevCats.getOrDefault(e.getKey(), 0.0);
            String change;
            Color cc;
            if (before <= 0) {
                change = "New";
                cc = UI.MUTED;
            } else {
                double p = (e.getValue() - before) / before * 100;
                change = String.format("%s%.0f%%", p >= 0 ? "+" : "\u2212", Math.abs(p));
                cc = Math.abs(p) < 1 ? UI.MUTED : p > 0 ? UI.DANGER : UI.SUCCESS;
            }
            JLabel ch = UI.label(change, Font.BOLD, 13, cc);
            ch.setHorizontalAlignment(SwingConstants.RIGHT);
            ch.setPreferredSize(new Dimension(64, 20));

            GridBagConstraints g = new GridBagConstraints();
            g.gridy = 0;
            g.anchor = GridBagConstraints.WEST;
            g.gridx = 0;
            r.add(name, g);
            g.gridx = 1;
            g.weightx = 1;
            g.fill = GridBagConstraints.HORIZONTAL;
            g.insets = new Insets(0, 10, 0, 10);
            r.add(bar, g);
            g.weightx = 0;
            g.fill = GridBagConstraints.NONE;
            g.insets = new Insets(0, 0, 0, 0);
            g.gridx = 2;
            r.add(pct, g);
            g.gridx = 3;
            r.add(amt, g);
            g.gridx = 4;
            r.add(ch, g);
            r.setMaximumSize(new Dimension(Integer.MAX_VALUE, r.getPreferredSize().height));
            r.setAlignmentX(LEFT_ALIGNMENT);
            categories.add(r);
        }
    }

    private void buildCompare(YearMonth m, YearMonth prev) {
        compare.removeAll();
        compareTitle.setText("Compared with " + AppContext.MONTH.format(prev));
        double in = ctx.transactions.getIncome(m);
        double out = ctx.transactions.getExpense(m);
        double pin = ctx.transactions.getIncome(prev);
        double pout = ctx.transactions.getExpense(prev);
        String nowName = AppContext.MONTH_SHORT.format(m);
        String prevName = AppContext.MONTH_SHORT.format(prev);
        compare.add(compareRow("", nowName, prevName, "Change", null, true));
        compare.add(compareRow("Income", Money.format(in), Money.format(pin), change(in, pin), deltaColor(in, pin, true), false));
        compare.add(compareRow("Expenses", Money.format(out), Money.format(pout), change(out, pout), deltaColor(out, pout, false), false));
        compare.add(compareRow("Savings", Money.format(in - out), Money.format(pin - pout), change(in - out, pin - pout), deltaColor(in - out, pin - pout, true), false));
        String rate = in > 0 ? String.format("%.1f%%", (in - out) / in * 100) : "--";
        String prate = pin > 0 ? String.format("%.1f%%", (pin - pout) / pin * 100) : "--";
        String rdiff = in > 0 && pin > 0 ? String.format("%+.1f pts", ((in - out) / in - (pin - pout) / pin) * 100) : "--";
        Color rc = in > 0 && pin > 0 ? deltaColor((in - out) / in, (pin - pout) / pin, true) : UI.MUTED;
        compare.add(compareRow("Savings rate", rate, prate, rdiff, rc, false));
        if (!ctx.transactions.hasData(prev)) {
            JLabel note = UI.label("No transactions recorded for " + AppContext.MONTH.format(prev) + ".", Font.PLAIN, 13, UI.MUTED);
            note.setBorder(new EmptyBorder(12, 0, 0, 0));
            note.setAlignmentX(LEFT_ALIGNMENT);
            compare.add(note);
        }
    }

    private static String change(double now, double before) {
        if (Math.abs(before) < 0.005) {
            return "--";
        }
        double p = (now - before) / Math.abs(before) * 100;
        return String.format("%s%.0f%%", p >= 0 ? "+" : "\u2212", Math.abs(p));
    }

    private static JPanel compareRow(String name, String now, String before, String change, Color changeColor, boolean head) {
        JPanel r = new JPanel(new GridLayout(1, 4, 8, 0));
        r.setOpaque(false);
        r.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, head ? UI.BORDER : new Color(241, 245, 249)),
                new EmptyBorder(head ? 4 : 11, 0, head ? 8 : 11, 0)));
        int style = head ? Font.BOLD : Font.PLAIN;
        int size = head ? 12 : 14;
        Color c = head ? UI.MUTED : UI.TEXT;
        r.add(UI.label(head ? "" : name, Font.BOLD, 14, UI.TEXT));
        JLabel a = UI.label(head ? now.toUpperCase() : now, head ? style : Font.BOLD, size, c);
        JLabel b = UI.label(head ? before.toUpperCase() : before, style, size, head ? UI.MUTED : UI.MUTED);
        JLabel d = UI.label(head ? change.toUpperCase() : change, Font.BOLD, size, head ? UI.MUTED : changeColor);
        a.setHorizontalAlignment(SwingConstants.RIGHT);
        b.setHorizontalAlignment(SwingConstants.RIGHT);
        d.setHorizontalAlignment(SwingConstants.RIGHT);
        r.add(a);
        r.add(b);
        r.add(d);
        r.setMaximumSize(new Dimension(Integer.MAX_VALUE, r.getPreferredSize().height));
        r.setAlignmentX(LEFT_ALIGNMENT);
        return r;
    }

    private static class RankBadge extends JComponent {

        private final int rank;

        RankBadge(int rank) {
            this.rank = rank;
            setPreferredSize(new Dimension(34, 34));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = AuthComponents.smooth(g);
            g2.setColor(rank == 1 ? UI.soft(UI.PURPLE) : new Color(241, 245, 249));
            g2.fillOval(0, 0, 34, 34);
            g2.setFont(UI.font(Font.BOLD, 14));
            FontMetrics fm = g2.getFontMetrics();
            String s = String.valueOf(rank);
            g2.setColor(rank == 1 ? UI.PURPLE : UI.MUTED);
            g2.drawString(s, (34 - fm.stringWidth(s)) / 2, (34 - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }
    }
}
