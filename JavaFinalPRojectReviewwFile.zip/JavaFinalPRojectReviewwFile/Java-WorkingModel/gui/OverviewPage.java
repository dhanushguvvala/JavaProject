package gui;

import model.Transaction;
import service.BudgetService;
import service.FinancialAnalysisService;
import util.Money;

import javax.swing.*;
import java.awt.*;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;

public class OverviewPage extends Page {

    private final UI.StatCard income = new UI.StatCard("INCOME", Icons.Type.TREND_UP, UI.SUCCESS);
    private final UI.StatCard expense = new UI.StatCard("EXPENSES", Icons.Type.TREND_DOWN, UI.DANGER);
    private final UI.StatCard savings = new UI.StatCard("SAVINGS", Icons.Type.WALLET, UI.PRIMARY);
    private final UI.StatCard score = new UI.StatCard("FINANCIAL SCORE", Icons.Type.SPARKLE, UI.PURPLE);
    private final Charts.BarChart trend = new Charts.BarChart(new String[]{"Income", "Expenses"},
            new Color[]{new Color(34, 197, 94), new Color(59, 130, 246)});
    private final Charts.DonutChart donut = new Charts.DonutChart();
    private final JPanel recent = stack();
    private final JPanel budgetList = stack();
    private List<YearMonth> trendMonths = List.of();

    public OverviewPage(AppContext ctx) {
        super(ctx);
        addRow(equalRow(income, expense, savings, score), 0);

        UI.Card trendCard = new UI.Card(new BorderLayout());
        trendCard.add(UI.cardHeader("Income vs expenses", "Last 6 months. Click a month to open it.", null), BorderLayout.NORTH);
        trend.setPreferredSize(new Dimension(300, 270));
        trend.setOnClick(i -> ctx.setMonth(trendMonths.get(i)));
        trendCard.add(trend, BorderLayout.CENTER);

        UI.Card donutCard = new UI.Card(new BorderLayout());
        donutCard.add(UI.cardHeader("Spending by category", "Where this month's money went", null), BorderLayout.NORTH);
        donut.setPreferredSize(new Dimension(300, 270));
        donutCard.add(donut, BorderLayout.CENTER);
        addRow(row(new double[]{0.58, 0.42}, trendCard, donutCard), 0);

        UI.AppButton viewAll = new UI.AppButton("View all", Icons.Type.CHEVRON_RIGHT, UI.Variant.LINK);
        viewAll.addActionListener(e -> ctx.navigate("transactions"));
        UI.Card recentCard = new UI.Card(new BorderLayout());
        recentCard.add(UI.cardHeader("Recent transactions", "Latest activity this month", viewAll), BorderLayout.NORTH);
        recentCard.add(top(recent), BorderLayout.CENTER);

        UI.AppButton manage = new UI.AppButton("Manage", Icons.Type.CHEVRON_RIGHT, UI.Variant.LINK);
        manage.addActionListener(e -> ctx.navigate("budgets"));
        UI.Card budgetCard = new UI.Card(new BorderLayout());
        budgetCard.add(UI.cardHeader("Budget status", "Spending against your limits", manage), BorderLayout.NORTH);
        budgetCard.add(top(budgetList), BorderLayout.CENTER);
        addRow(row(new double[]{0.58, 0.42}, recentCard, budgetCard), 1);
    }

    @Override
    public String title() {
        return "Dashboard";
    }

    @Override
    public String subtitle() {
        return "Welcome back, " + ctx.username + ". Here's " + AppContext.MONTH.format(ctx.getMonth()) + " at a glance.";
    }

    @Override
    public void refresh() {
        YearMonth m = ctx.getMonth();
        YearMonth prev = m.minusMonths(1);
        String prevName = AppContext.MONTH_SHORT.format(prev);
        double in = ctx.transactions.getIncome(m);
        double out = ctx.transactions.getExpense(m);
        double pin = ctx.transactions.getIncome(prev);
        double pout = ctx.transactions.getExpense(prev);
        double save = in - out;

        income.set(Money.format(in), UI.TEXT, delta(in, pin, prevName), deltaColor(in, pin, true));
        expense.set(Money.format(out), UI.TEXT, delta(out, pout, prevName), deltaColor(out, pout, false));
        savings.set(Money.format(save), save < 0 ? UI.DANGER : UI.TEXT,
                in > 0 ? String.format("%.1f%% of income saved", save / in * 100) : "No income this month",
                save < 0 ? UI.DANGER : UI.MUTED);

        FinancialAnalysisService.Report r = ctx.analysis.analyze(m);
        if (r.hasData()) {
            score.set(r.score() + " / 100", UI.TEXT, r.grade(), UI.scoreColor(r.score()));
        } else {
            score.set("--", UI.FAINT, "No data this month", UI.MUTED);
        }

        trendMonths = new java.util.ArrayList<>();
        for (int i = 5; i >= 0; i--) {
            trendMonths.add(m.minusMonths(i));
        }
        String[] labels = new String[6];
        String[] tips = new String[6];
        double[][] vals = new double[6][2];
        for (int i = 0; i < 6; i++) {
            YearMonth ym = trendMonths.get(i);
            labels[i] = AppContext.MONTH_SHORT.format(ym);
            tips[i] = AppContext.MONTH.format(ym);
            vals[i][0] = ctx.transactions.getIncome(ym);
            vals[i][1] = ctx.transactions.getExpense(ym);
        }
        trend.setData(labels, tips, vals, 5, 1);

        donut.setData(ctx.transactions.getExpenseByCategory(m), "spent");

        recent.removeAll();
        List<Transaction> list = ctx.transactions.getTransactions(m);
        if (list.isEmpty()) {
            recent.add(UI.emptyState(Icons.Type.RECEIPT, "No transactions yet", "Use Add transaction to record income or spending."));
        } else {
            for (Transaction t : list.subList(0, Math.min(6, list.size()))) {
                Color c = UI.categoryColor(t.getCategory());
                recent.add(new ListRow(new UI.IconBadge(t.isIncome() ? Icons.Type.TREND_UP : Icons.Type.RECEIPT, c, 38),
                        t.getDescription(), t.getCategory() + "  \u2022  " + AppContext.DATE.format(t.getDate()),
                        Money.signed(t.getAmount(), t.isIncome()), t.isIncome() ? UI.SUCCESS : UI.TEXT));
            }
        }

        budgetList.removeAll();
        Map<String, Double> limits = ctx.budgets.getLimits();
        if (limits.isEmpty()) {
            JPanel empty = UI.emptyState(Icons.Type.TARGET, "No budgets set", "Set monthly limits to get overspending alerts.");
            budgetList.add(empty);
        } else {
            Map<String, Double> spent = ctx.transactions.getExpenseByCategory(m);
            int shown = 0;
            for (Map.Entry<String, Double> e : limits.entrySet()) {
                if (shown++ == 5) {
                    break;
                }
                budgetList.add(budgetRow(e.getKey(), spent.getOrDefault(e.getKey(), 0.0), e.getValue()));
            }
        }
        revalidate();
        repaint();
    }

    static JPanel budgetRow(String category, double spent, double limit) {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(8, 0, 10, 0));
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JPanel name = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        name.setOpaque(false);
        name.add(new UI.Dot(UI.categoryColor(category)));
        name.add(UI.label(category, Font.BOLD, 14, UI.TEXT));
        top.add(name, BorderLayout.WEST);
        BudgetService.Status st = BudgetService.status(spent, limit);
        Color c = switch (st) {
            case OVER -> UI.DANGER;
            case NEAR_LIMIT -> UI.WARNING;
            default -> UI.SUCCESS;
        };
        top.add(UI.label(Money.format(spent) + " of " + Money.format(limit), Font.PLAIN, 13, st == BudgetService.Status.OVER ? UI.DANGER : UI.MUTED), BorderLayout.EAST);
        UI.Progress bar = new UI.Progress();
        bar.set(spent / limit, c);
        p.add(top, BorderLayout.NORTH);
        p.add(bar, BorderLayout.CENTER);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, p.getPreferredSize().height));
        p.setAlignmentX(LEFT_ALIGNMENT);
        return p;
    }
}
