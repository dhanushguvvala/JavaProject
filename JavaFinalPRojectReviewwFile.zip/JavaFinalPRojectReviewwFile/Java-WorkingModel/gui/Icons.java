package gui;

import javax.swing.Icon;
import java.awt.*;
import java.awt.geom.*;

public final class Icons {

    public enum Type {
        DASHBOARD, LIST, CALENDAR, SPARKLE, TARGET, LOGOUT, PLUS, EDIT, TRASH, DOWNLOAD, SEARCH,
        CHEVRON_LEFT, CHEVRON_RIGHT, CHEVRON_DOWN, ARROW_UP, ARROW_DOWN, WALLET, TREND_UP, TREND_DOWN,
        CHECK, ALERT, BULB, CHART, RECEIPT, CLOCK, SAVE
    }

    private Icons() {
    }

    public static Icon of(Type type, int size, Color color) {
        return new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = AuthComponents.smooth(g);
                paint(g2, type, x, y, size, color);
                g2.dispose();
            }

            @Override
            public int getIconWidth() {
                return size;
            }

            @Override
            public int getIconHeight() {
                return size;
            }
        };
    }

    public static void paint(Graphics2D g, Type type, double x, double y, double size, Color color) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.translate(x, y);
        g2.scale(size / 24.0, size / 24.0);
        g2.setColor(color);
        g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        switch (type) {
            case DASHBOARD -> {
                g2.draw(new RoundRectangle2D.Double(4, 4, 7, 7, 3, 3));
                g2.draw(new RoundRectangle2D.Double(13, 4, 7, 7, 3, 3));
                g2.draw(new RoundRectangle2D.Double(4, 13, 7, 7, 3, 3));
                g2.draw(new RoundRectangle2D.Double(13, 13, 7, 7, 3, 3));
            }
            case LIST -> {
                line(g2, 9, 6, 20, 6);
                line(g2, 9, 12, 20, 12);
                line(g2, 9, 18, 20, 18);
                dot(g2, 4.5, 6, 1.4);
                dot(g2, 4.5, 12, 1.4);
                dot(g2, 4.5, 18, 1.4);
            }
            case CALENDAR -> {
                g2.draw(new RoundRectangle2D.Double(4, 5, 16, 15, 4, 4));
                line(g2, 4, 10, 20, 10);
                line(g2, 8, 3, 8, 7);
                line(g2, 16, 3, 16, 7);
            }
            case SPARKLE -> {
                g2.draw(star(11, 13, 8));
                g2.fill(star(18.5, 5, 2.8));
            }
            case TARGET -> {
                g2.draw(new Ellipse2D.Double(3.5, 3.5, 17, 17));
                g2.draw(new Ellipse2D.Double(7.5, 7.5, 9, 9));
                dot(g2, 12, 12, 1.8);
            }
            case LOGOUT -> {
                path(g2, new double[]{13, 4, 6, 4, 6, 20, 13, 20});
                line(g2, 10, 12, 20, 12);
                path(g2, new double[]{16.5, 8.5, 20, 12, 16.5, 15.5});
            }
            case PLUS -> {
                line(g2, 12, 5, 12, 19);
                line(g2, 5, 12, 19, 12);
            }
            case EDIT -> {
                path(g2, new double[]{4, 20, 4, 16, 15, 5, 19, 9, 8, 20, 4, 20});
                line(g2, 13, 7, 17, 11);
            }
            case TRASH -> {
                line(g2, 4, 7, 20, 7);
                path(g2, new double[]{6, 7, 7, 20, 17, 20, 18, 7});
                path(g2, new double[]{9, 7, 9, 4, 15, 4, 15, 7});
                line(g2, 10, 11, 10, 16);
                line(g2, 14, 11, 14, 16);
            }
            case DOWNLOAD -> {
                line(g2, 12, 4, 12, 15);
                path(g2, new double[]{8, 11, 12, 15, 16, 11});
                path(g2, new double[]{4, 17, 4, 20, 20, 20, 20, 17});
            }
            case SEARCH -> {
                g2.draw(new Ellipse2D.Double(4, 4, 13, 13));
                line(g2, 15.5, 15.5, 20, 20);
            }
            case CHEVRON_LEFT -> path(g2, new double[]{15, 5, 8, 12, 15, 19});
            case CHEVRON_RIGHT -> path(g2, new double[]{9, 5, 16, 12, 9, 19});
            case CHEVRON_DOWN -> path(g2, new double[]{6, 9, 12, 15, 18, 9});
            case ARROW_UP -> {
                line(g2, 12, 19, 12, 5);
                path(g2, new double[]{6, 11, 12, 5, 18, 11});
            }
            case ARROW_DOWN -> {
                line(g2, 12, 5, 12, 19);
                path(g2, new double[]{6, 13, 12, 19, 18, 13});
            }
            case WALLET -> {
                g2.draw(new RoundRectangle2D.Double(3, 7, 18, 13, 4, 4));
                path(g2, new double[]{6, 7, 15, 3.5, 17, 7});
                g2.draw(new RoundRectangle2D.Double(14, 11.5, 7, 5, 2, 2));
                dot(g2, 17, 14, 1);
            }
            case TREND_UP -> {
                path(g2, new double[]{3, 17, 9, 11, 13, 15, 21, 7});
                path(g2, new double[]{15, 7, 21, 7, 21, 13});
            }
            case TREND_DOWN -> {
                path(g2, new double[]{3, 7, 9, 13, 13, 9, 21, 17});
                path(g2, new double[]{21, 11, 21, 17, 15, 17});
            }
            case CHECK -> path(g2, new double[]{5, 12.5, 10, 17.5, 19, 7});
            case ALERT -> {
                path(g2, new double[]{12, 3.5, 21.5, 20, 2.5, 20, 12, 3.5});
                line(g2, 12, 9.5, 12, 14);
                dot(g2, 12, 17, 1.2);
            }
            case BULB -> {
                g2.draw(new Arc2D.Double(6, 3, 12, 12, -50, 280, Arc2D.OPEN));
                path(g2, new double[]{8.2, 13.6, 9.5, 17, 14.5, 17, 15.8, 13.6});
                line(g2, 10, 20.5, 14, 20.5);
            }
            case CHART -> {
                line(g2, 4, 20, 20, 20);
                line(g2, 7, 20, 7, 13);
                line(g2, 12, 20, 12, 8);
                line(g2, 17, 20, 17, 4);
            }
            case RECEIPT -> {
                path(g2, new double[]{6, 3, 18, 3, 18, 21, 15, 19, 12, 21, 9, 19, 6, 21, 6, 3});
                line(g2, 9, 8, 15, 8);
                line(g2, 9, 12, 15, 12);
                line(g2, 9, 16, 13, 16);
            }
            case CLOCK -> {
                g2.draw(new Ellipse2D.Double(3.5, 3.5, 17, 17));
                path(g2, new double[]{12, 7.5, 12, 12, 15, 14});
            }
            case SAVE -> {
                path(g2, new double[]{5, 4, 16, 4, 20, 8, 20, 20, 5, 20, 5, 4});
                path(g2, new double[]{8, 4, 8, 9, 15, 9, 15, 4});
                g2.draw(new RoundRectangle2D.Double(8, 13, 9, 7, 1, 1));
            }
        }
        g2.dispose();
    }

    private static void line(Graphics2D g2, double x1, double y1, double x2, double y2) {
        g2.draw(new Line2D.Double(x1, y1, x2, y2));
    }

    private static void dot(Graphics2D g2, double cx, double cy, double r) {
        g2.fill(new Ellipse2D.Double(cx - r, cy - r, r * 2, r * 2));
    }

    private static void path(Graphics2D g2, double[] pts) {
        Path2D p = new Path2D.Double();
        p.moveTo(pts[0], pts[1]);
        for (int i = 2; i < pts.length; i += 2) {
            p.lineTo(pts[i], pts[i + 1]);
        }
        g2.draw(p);
    }

    private static Shape star(double cx, double cy, double r) {
        Path2D p = new Path2D.Double();
        double k = r * 0.18;
        p.moveTo(cx, cy - r);
        p.quadTo(cx + k, cy - k, cx + r, cy);
        p.quadTo(cx + k, cy + k, cx, cy + r);
        p.quadTo(cx - k, cy + k, cx - r, cy);
        p.quadTo(cx - k, cy - k, cx, cy - r);
        p.closePath();
        return p;
    }
}
