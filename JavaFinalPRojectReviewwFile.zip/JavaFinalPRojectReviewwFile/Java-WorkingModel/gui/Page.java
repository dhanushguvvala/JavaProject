package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public abstract class Page extends UI.ScrollablePanel {

    protected final AppContext ctx;
    private int rows;

    protected Page(AppContext ctx) {
        super(new GridBagLayout());
        this.ctx = ctx;
        setBackground(UI.BG);
        setBorder(new EmptyBorder(24, 28, 28, 28));
    }

    public abstract String title();

    public abstract String subtitle();

    public abstract void refresh();

    public boolean scrolls() {
        return true;
    }

    protected void addRow(JComponent row, double weighty) {
        add(row, UI.gbc(0, rows, 1, 1, weighty, new Insets(rows == 0 ? 0 : 20, 0, 0, 0)));
        rows++;
    }

    protected static JPanel row(double[] weights, JComponent... comps) {
        JPanel p = new JPanel(new RowLayout(weights, 20));
        p.setOpaque(false);
        for (JComponent c : comps) {
            p.add(c);
        }
        return p;
    }

    protected static JPanel equalRow(JComponent... comps) {
        double[] w = new double[comps.length];
        java.util.Arrays.fill(w, 1);
        return row(w, comps);
    }

    protected static JPanel top(JComponent body) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.add(body, BorderLayout.NORTH);
        return p;
    }

    static class RowLayout implements LayoutManager {

        private final double[] weights;
        private final int gap;

        RowLayout(double[] weights, int gap) {
            this.weights = weights;
            this.gap = gap;
        }

        @Override
        public void addLayoutComponent(String name, Component comp) {
        }

        @Override
        public void removeLayoutComponent(Component comp) {
        }

        private int[] widths(int total, int n) {
            double sum = 0;
            for (int i = 0; i < n; i++) {
                sum += weights[i];
            }
            int avail = Math.max(0, total - gap * (n - 1));
            int[] w = new int[n];
            int used = 0;
            for (int i = 0; i < n; i++) {
                w[i] = i == n - 1 ? avail - used : (int) (avail * weights[i] / sum);
                used += w[i];
            }
            return w;
        }

        @Override
        public Dimension preferredLayoutSize(Container parent) {
            int h = 0;
            for (Component c : parent.getComponents()) {
                h = Math.max(h, c.getPreferredSize().height);
            }
            Insets in = parent.getInsets();
            return new Dimension(200, h + in.top + in.bottom);
        }

        @Override
        public Dimension minimumLayoutSize(Container parent) {
            return preferredLayoutSize(parent);
        }

        @Override
        public void layoutContainer(Container parent) {
            Insets in = parent.getInsets();
            Component[] comps = parent.getComponents();
            int[] w = widths(parent.getWidth() - in.left - in.right, comps.length);
            int x = in.left;
            int h = parent.getHeight() - in.top - in.bottom;
            for (int i = 0; i < comps.length; i++) {
                comps[i].setBounds(x, in.top, w[i], h);
                x += w[i] + gap;
            }
        }
    }

    protected static JPanel stack() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        return p;
    }

    protected static String delta(double now, double before, String prevName) {
        if (before <= 0) {
            return now > 0 ? "No data for " + prevName : "";
        }
        double pct = (now - before) / before * 100;
        return String.format("%s%.0f%% vs %s", pct >= 0 ? "+" : "\u2212", Math.abs(pct), prevName);
    }

    protected static Color deltaColor(double now, double before, boolean higherIsGood) {
        if (before <= 0 || Math.abs(now - before) < 0.005) {
            return UI.MUTED;
        }
        return (now > before) == higherIsGood ? UI.SUCCESS : UI.DANGER;
    }

    static class ListRow extends JPanel {

        ListRow(JComponent left, String title, String sub, String right, Color rightColor) {
            super(new BorderLayout(14, 0));
            setOpaque(false);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(241, 245, 249)), new EmptyBorder(10, 0, 10, 0)));
            JPanel texts = new JPanel(new GridLayout(2, 1, 0, 2));
            texts.setOpaque(false);
            texts.add(UI.label(title, Font.BOLD, 14, UI.TEXT));
            texts.add(UI.label(sub, Font.PLAIN, 12, UI.MUTED));
            if (left != null) {
                JPanel l = new JPanel(new GridBagLayout());
                l.setOpaque(false);
                l.add(left);
                add(l, BorderLayout.WEST);
            }
            add(texts, BorderLayout.CENTER);
            add(UI.label(right, Font.BOLD, 14, rightColor), BorderLayout.EAST);
            setMaximumSize(new Dimension(Integer.MAX_VALUE, getPreferredSize().height));
            setAlignmentX(LEFT_ALIGNMENT);
        }
    }
}
