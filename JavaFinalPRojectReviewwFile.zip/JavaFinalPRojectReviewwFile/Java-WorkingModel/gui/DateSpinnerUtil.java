package gui;

import javax.swing.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class DateSpinnerUtil {

    private DateSpinnerUtil() {
    }

    public static JSpinner createDateSpinner() {
        return createDateSpinner(LocalDate.now());
    }

    public static JSpinner createDateSpinner(LocalDate initialDate) {

        SpinnerDateModel model = new SpinnerDateModel();
        JSpinner spinner = new JSpinner(model);

        JSpinner.DateEditor editor = new JSpinner.DateEditor(spinner, "yyyy-MM-dd");
        spinner.setEditor(editor);

        LocalDate date = initialDate != null ? initialDate : LocalDate.now();
        Date asDate = Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
        spinner.setValue(asDate);

        return spinner;
    }

    public static LocalDate getSelectedDate(JSpinner spinner) {
        Date value = (Date) spinner.getValue();
        return value.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

}
