package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.*;

public final class AuthComponents {

    public static final Color NAVY = new Color(10, 44, 98);
    public static final Color NAVY_DARK = new Color(6, 30, 74);
    public static final Color PRIMARY = new Color(11, 99, 229);
    public static final Color PRIMARY_HOVER = new Color(9, 86, 204);
    public static final Color PRIMARY_PRESSED = new Color(7, 70, 170);
    public static final Color PRIMARY_SOFT = new Color(240, 246, 255);
    public static final Color OUTLINE = new Color(128, 168, 232);
    public static final Color HEADING = new Color(14, 38, 84);
    public static final Color SUBTEXT = new Color(100, 116, 139);
    public static final Color LABEL = new Color(15, 23, 42);
    public static final Color BORDER = new Color(208, 216, 228);
    public static final Color PLACEHOLDER = new Color(148, 163, 184);
    public static final Color ICON = new Color(84, 96, 116);
    public static final int FORM_WIDTH = 460;

    private AuthComponents() {
    }

    public static Font font(int style, int size) {
        return new Font("Segoe UI", style, size);
    }

    static Graphics2D smooth(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        return g2;
    }

    static void drawArrow(Graphics2D g2, int x, int y, boolean right, Color color) {
        g2.setColor(color);
        g2.setStroke(new BasicStroke(2.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        Path2D p = new Path2D.Double();
        if (right) {
            p.moveTo(x, y);
            p.lineTo(x + 20, y);
            p.moveTo(x + 13, y - 7);
            p.lineTo(x + 20, y);
            p.lineTo(x + 13, y + 7);
        } else {
            p.moveTo(x + 20, y);
            p.lineTo(x, y);
            p.moveTo(x + 7, y - 7);
            p.lineTo(x, y);
            p.lineTo(x + 7, y + 7);
        }
        g2.draw(p);
    }

    static void drawCenteredString(Graphics2D g2, String text, int cx, int baseline) {
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(text, cx - fm.stringWidth(text) / 2, baseline);
    }

    public enum FieldIcon { USER, LOCK }

    public static class BrandPanel extends JPanel {

        public BrandPanel() {
            setPreferredSize(new Dimension(400, 0));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            int w = getWidth();
            int h = getHeight();
            g2.setPaint(new GradientPaint(0, 0, NAVY, 0, h, NAVY_DARK));
            g2.fillRect(0, 0, w, h);

            int cx = w / 2;
            int top = (int) (h * 0.11);
            drawWallet(g2, cx, top);

            g2.setColor(Color.WHITE);
            g2.setFont(font(Font.BOLD, 34));
            drawCenteredString(g2, "Personal Finance", cx, top + 232);
            drawCenteredString(g2, "Tracker", cx, top + 280);

            g2.setColor(new Color(214, 224, 240));
            g2.setFont(font(Font.PLAIN, 18));
            drawCenteredString(g2, "Track  \u2022  Plan  \u2022  Save  \u2022  Grow", cx, top + 326);

            drawBars(g2, cx, top + 352, h - 48);
            g2.dispose();
        }

        private void drawWallet(Graphics2D g2, int cx, int top) {
            g2.setColor(new Color(21, 87, 192));
            g2.fill(new RoundRectangle2D.Double(cx - 72, top + 56, 144, 50, 18, 18));

            double coinX = cx - 47;
            double coinY = top;
            g2.setPaint(new GradientPaint(0, top, new Color(252, 211, 77), 0, top + 84, new Color(234, 160, 12)));
            g2.fill(new Ellipse2D.Double(coinX, coinY, 84, 84));
            g2.setColor(new Color(202, 128, 8));
            g2.setStroke(new BasicStroke(2.5f));
            g2.draw(new Ellipse2D.Double(coinX + 8, coinY + 8, 68, 68));

            Font rupee = font(Font.BOLD, 40);
            if (!rupee.canDisplay('\u20B9')) {
                rupee = new Font(Font.SANS_SERIF, Font.BOLD, 40);
            }
            g2.setFont(rupee);
            g2.setColor(new Color(160, 96, 6));
            drawCenteredString(g2, "\u20B9", (int) (coinX + 42), (int) (coinY + 56));

            g2.setPaint(new GradientPaint(0, top + 68, new Color(45, 127, 240), 0, top + 172, new Color(24, 100, 222)));
            g2.fill(new RoundRectangle2D.Double(cx - 72, top + 68, 144, 104, 22, 22));

            g2.setColor(new Color(21, 87, 192));
            g2.fill(new RoundRectangle2D.Double(cx + 30, top + 100, 50, 38, 16, 16));
            g2.setColor(new Color(214, 228, 250));
            g2.fill(new Ellipse2D.Double(cx + 44, top + 113, 12, 12));
        }

        private void drawBars(Graphics2D g2, int cx, int minTop, int bottom) {
            int maxH = Math.min(220, bottom - minTop);
            if (maxH < 40) {
                return;
            }
            double[] ratios = {0.32, 0.46, 0.62, 0.78, 1.0};
            int bw = 44;
            int gap = 18;
            int x = cx - (ratios.length * bw + (ratios.length - 1) * gap) / 2;
            for (double r : ratios) {
                int bh = (int) (maxH * r);
                g2.setPaint(new GradientPaint(0, bottom - bh, new Color(64, 110, 180, 170), 0, bottom, new Color(40, 82, 150, 110)));
                g2.fill(new RoundRectangle2D.Double(x, bottom - bh, bw, bh, 6, 6));
                x += bw + gap;
            }
        }
    }

    static void paintHint(JTextComponent c, Graphics g, String hint) {
        if (c.getDocument().getLength() > 0) {
            return;
        }
        Graphics2D g2 = smooth(g);
        g2.setColor(PLACEHOLDER);
        g2.setFont(c.getFont());
        FontMetrics fm = g2.getFontMetrics();
        Insets in = c.getInsets();
        int y = (c.getHeight() - fm.getHeight()) / 2 + fm.getAscent();
        g2.drawString(hint, in.left + 2, y);
        g2.dispose();
    }

    public static class HintTextField extends JTextField {

        private final String hint;

        public HintTextField(String hint) {
            this.hint = hint;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            paintHint(this, g, hint);
        }
    }

    public static class HintPasswordField extends JPasswordField {

        private final String hint;

        public HintPasswordField(String hint) {
            this.hint = hint;
            setEchoChar('\u2022');
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            paintHint(this, g, hint);
        }
    }

    public static class IconField extends JPanel {

        private final JTextComponent input;
        private final FieldIcon icon;

        public IconField(JTextComponent input, FieldIcon icon) {
            super(new BorderLayout());
            this.input = input;
            this.icon = icon;
            setOpaque(false);
            setBorder(new EmptyBorder(0, 54, 0, 16));
            setPreferredSize(new Dimension(FORM_WIDTH, 54));
            setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));

            input.setBorder(null);
            input.setOpaque(false);
            input.setFont(font(Font.PLAIN, 17));
            input.setForeground(LABEL);
            input.setCaretColor(PRIMARY);
            input.setSelectionColor(new Color(191, 219, 254));
            add(input, BorderLayout.CENTER);

            input.addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    repaint();
                }

                @Override
                public void focusLost(FocusEvent e) {
                    repaint();
                }
            });

            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    input.requestFocusInWindow();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            boolean focused = input.isFocusOwner();
            double inset = focused ? 1 : 0.6;
            Shape box = new RoundRectangle2D.Double(inset, inset, getWidth() - inset * 2, getHeight() - inset * 2, 10, 10);
            g2.setColor(Color.WHITE);
            g2.fill(box);
            g2.setColor(focused ? PRIMARY : BORDER);
            g2.setStroke(new BasicStroke(focused ? 2f : 1.2f));
            g2.draw(box);

            int cy = getHeight() / 2;
            Color c = focused ? PRIMARY : ICON;
            if (icon == FieldIcon.USER) {
                paintUserIcon(g2, 20, cy, c);
            } else {
                paintLockIcon(g2, 20, cy, c);
            }
            g2.dispose();
        }

        private void paintUserIcon(Graphics2D g2, int x, int cy, Color c) {
            g2.setColor(c);
            g2.fill(new Ellipse2D.Double(x + 5, cy - 12, 12, 12));
            g2.fill(new Arc2D.Double(x, cy + 2, 22, 20, 0, 180, Arc2D.CHORD));
        }

        private void paintLockIcon(Graphics2D g2, int x, int cy, Color c) {
            g2.setColor(c);
            g2.setStroke(new BasicStroke(2.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.draw(new Arc2D.Double(x + 5, cy - 12, 12, 14, 0, 180, Arc2D.OPEN));
            g2.draw(new Line2D.Double(x + 5, cy - 5, x + 5, cy - 2));
            g2.draw(new Line2D.Double(x + 17, cy - 5, x + 17, cy - 2));
            g2.fill(new RoundRectangle2D.Double(x + 1, cy - 3, 20, 16, 5, 5));
            g2.setColor(Color.WHITE);
            g2.fill(new Ellipse2D.Double(x + 8.5, cy + 1, 5, 5));
            g2.fill(new Rectangle2D.Double(x + 10, cy + 4, 2, 5));
        }
    }

    private static void styleButton(AbstractButton b, int width, int height) {
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setOpaque(false);
        b.setRolloverEnabled(true);
        b.setFont(font(Font.BOLD, 17));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(width, height));
    }

    public static class PrimaryButton extends JButton {

        private final boolean arrow;

        public PrimaryButton(String text, boolean arrow) {
            super(text);
            this.arrow = arrow;
            styleButton(this, FORM_WIDTH, 56);
            setForeground(Color.WHITE);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            ButtonModel m = getModel();
            g2.setColor(m.isPressed() ? PRIMARY_PRESSED : m.isRollover() ? PRIMARY_HOVER : PRIMARY);
            g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 10, 10));

            g2.setFont(getFont());
            g2.setColor(getForeground());
            FontMetrics fm = g2.getFontMetrics();
            int baseline = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            drawCenteredString(g2, getText(), getWidth() / 2, baseline);
            if (arrow) {
                drawArrow(g2, getWidth() - 50, getHeight() / 2, true, getForeground());
            }
            g2.dispose();
        }
    }

    public static class OutlineButton extends JButton {

        private final boolean backArrow;

        public OutlineButton(String text, boolean backArrow) {
            super(text);
            this.backArrow = backArrow;
            styleButton(this, FORM_WIDTH, 56);
            setForeground(PRIMARY);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            ButtonModel m = getModel();
            Shape box = new RoundRectangle2D.Double(0.75, 0.75, getWidth() - 1.5, getHeight() - 1.5, 10, 10);
            g2.setColor(m.isRollover() || m.isPressed() ? PRIMARY_SOFT : Color.WHITE);
            g2.fill(box);
            g2.setColor(m.isRollover() ? PRIMARY : OUTLINE);
            g2.setStroke(new BasicStroke(1.5f));
            g2.draw(box);

            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            int baseline = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            int textW = fm.stringWidth(getText());
            int groupW = backArrow ? textW + 38 : textW;
            int x = (getWidth() - groupW) / 2;
            if (backArrow) {
                drawArrow(g2, x, getHeight() / 2, false, getForeground());
                x += 38;
            }
            g2.setColor(getForeground());
            g2.drawString(getText(), x, baseline);
            g2.dispose();
        }
    }

    public static class OrDivider extends JComponent {

        public OrDivider() {
            setPreferredSize(new Dimension(FORM_WIDTH, 22));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = smooth(g);
            g2.setFont(font(Font.PLAIN, 15));
            FontMetrics fm = g2.getFontMetrics();
            int cy = getHeight() / 2;
            int tw = fm.stringWidth("OR");
            int cx = getWidth() / 2;
            g2.setColor(BORDER);
            g2.fillRect(0, cy, cx - tw / 2 - 14, 1);
            g2.fillRect(cx + tw / 2 + 14, cy, getWidth(), 1);
            g2.setColor(SUBTEXT);
            drawCenteredString(g2, "OR", cx, cy + fm.getAscent() / 2 - 1);
            g2.dispose();
        }
    }

    public static class FormPanel extends JPanel {

        private final GridBagConstraints c = new GridBagConstraints();

        public FormPanel() {
            super(new GridBagLayout());
            setOpaque(false);
            c.gridx = 0;
            c.gridy = 0;
            c.weightx = 1;
            c.fill = GridBagConstraints.HORIZONTAL;
            c.anchor = GridBagConstraints.WEST;
        }

        public FormPanel heading(String title, String subtitle) {
            JLabel t = new JLabel(title);
            t.setFont(font(Font.BOLD, 40));
            t.setForeground(HEADING);
            JLabel s = new JLabel(subtitle);
            s.setFont(font(Font.PLAIN, 19));
            s.setForeground(SUBTEXT);
            return row(t, 0).row(s, 4);
        }

        public FormPanel field(String label, JComponent field, int top) {
            JLabel l = new JLabel(label);
            l.setFont(font(Font.BOLD, 17));
            l.setForeground(LABEL);
            return row(l, top).row(field, 8);
        }

        public FormPanel row(JComponent comp, int top) {
            c.insets = new Insets(top, 0, 0, 0);
            add(comp, c);
            c.gridy++;
            return this;
        }
    }

    public static JPanel layout(FormPanel form) {
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(Color.WHITE);
        right.setBorder(new EmptyBorder(24, 48, 24, 48));
        right.add(form);

        JPanel root = new JPanel(new BorderLayout());
        root.add(new BrandPanel(), BorderLayout.WEST);
        root.add(right, BorderLayout.CENTER);
        return root;
    }
}
