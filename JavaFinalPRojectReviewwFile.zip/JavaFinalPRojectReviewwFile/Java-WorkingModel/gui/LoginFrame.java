package gui;

import service.LoginService;

import javax.swing.*;
import java.awt.*;

import static gui.AuthComponents.*;

public class LoginFrame extends JFrame {

    private final HintTextField usernameField = new HintTextField("Enter username");
    private final HintPasswordField passwordField = new HintPasswordField("Enter password");

    public LoginFrame() {

        setTitle("Personal Finance Tracker - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        PrimaryButton loginButton = new PrimaryButton("Login", true);
        OutlineButton registerButton = new OutlineButton("Create New Account", false);

        FormPanel form = new FormPanel()
                .heading("Welcome Back!", "Login to manage your finances")
                .field("Username", new IconField(usernameField, FieldIcon.USER), 34)
                .field("Password", new IconField(passwordField, FieldIcon.LOCK), 20)
                .row(loginButton, 32)
                .row(new OrDivider(), 18)
                .row(registerButton, 18);

        setContentPane(AuthComponents.layout(form));

        loginButton.addActionListener(e -> login());

        registerButton.addActionListener(e -> {
            dispose();
            new RegisterFrame();
        });

        getRootPane().setDefaultButton(loginButton);

        setSize(1000, 660);
        setMinimumSize(new Dimension(920, 620));
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void login() {

        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            MessageDialog.show(this, "Login Required",
                    "Please enter both username and password.", MessageDialog.Type.INFO);
            (username.isEmpty() ? usernameField : passwordField).requestFocusInWindow();
            return;
        }

        LoginService loginService = new LoginService();

        if (loginService.login(username, password)) {
            dispose();
            new Dashboard(username);
        } else {
            MessageDialog.show(this, "Login Failed",
                    "Invalid username or password.", MessageDialog.Type.ERROR);
            passwordField.setText("");
            passwordField.requestFocusInWindow();
        }
    }
}
